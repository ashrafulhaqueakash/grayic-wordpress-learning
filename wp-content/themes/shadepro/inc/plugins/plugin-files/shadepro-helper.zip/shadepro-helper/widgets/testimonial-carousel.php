<?php


/**
 * Elementor oEmbed Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class ShadeProTestimonialCarousel extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve oEmbed widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'shadepro-testimonial';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve oEmbed widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'ShadePro Testimonial', 'shadepro-ts' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve oEmbed widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-testimonial';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the oEmbed widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'shadepro-addons' ];
	}

	/**
	 * Register oEmbed widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls() {

		/**
		 * Content tab
		 */
		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content', 'shadepro-ts' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'testimonial_title',
			[
				'label' => __( 'Testimonial title', 'shadepro-ts' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => '',
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'image',
			[
				'label' => __( 'Choose Image', 'shadepro-ts' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);
		$repeater->add_control(
			'name', [
				'label' => __( 'Name', 'shadepro-ts' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'David Mark' , 'shadepro-ts' ),
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'title', [
				'label' => __( 'Title', 'shadepro-ts' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'CEO of Lapsas' , 'shadepro-ts' ),
				'show_label' => true,
			]
		);

		$repeater->add_control(
			'content', [
				'label' => __( 'Content', 'shadepro-ts' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'show_label' => true,
			]
		);

		$repeater->add_control(
			'star',
			[
				'label' => __( 'Select star', 'shadepro-ts' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => '5',
				'options' => [
					'1' => __( '1', 'shadepro-ts' ),
					'2' => __( '2', 'shadepro-ts' ),
					'3' => __( '3', 'shadepro-ts' ),
					'4' => __( '4', 'shadepro-ts' ),
					'5' => __( '5', 'shadepro-ts' ),
				],
			]
		);
		$this->add_control(
			'testimonial',
			[
				'label' => __( 'Repeater List', 'shadepro-ts' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'slide_settings',
			[
				'label' => __( 'SLide Settings', 'shadepro-ts' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);


		$this->add_control(
			'slide_perview_extra_large',
			[
				'label' => __( 'Slide to show in big screen', 'shadepro-ts' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'fields' => $repeater->get_controls(),
				'default' => 4,
				'separator' => '',
			]
		);
		$this->add_control(
			'slide_perview_desktop',
			[
				'label' => __( 'Slide to show in desktop', 'shadepro-ts' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'fields' => $repeater->get_controls(),
				'default' => 3,
			]
		);
		$this->add_control(
			'slide_perview_tablet',
			[
				'label' => __( 'Slide to show in tablet', 'shadepro-ts' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'fields' => $repeater->get_controls(),
				'default' => 2,
			]
		);
		$this->add_control(
			'slide_perview_mobile',
			[
				'label' => __( 'Slide to show in mobile', 'shadepro-ts' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'fields' => $repeater->get_controls(),
				'default' => 1,
			]
		);

		$this->end_controls_section();

		/**
		 * Style tab
		 */

		$this->start_controls_section(
			'general',
			[
				'label' => __( 'General', 'shadepro-ts' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'heading_typography',
				'label' => __( 'Title Typography', 'shadepro-ts' ),
				'scheme' => \Elementor\Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .shadepro-testimonial-item h4',
			]
		);


		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'box_shadow',
				'label' => __( 'Item Box Shadow', 'shadepro-ts' ),
				'selector' => '{{WRAPPER}} .shadepro-testimonial-item',

			]
		);



		$this->end_controls_section();


	}

	/**
	 * Render oEmbed widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		$popular_post_key = array();
		$popular_meta_value_num =array();
		$settings = $this->get_settings_for_display();
		?>
		<?php if ( $settings['testimonial'] ) :?>
		<div class="shadepro-testimonial-carousel swiper-container">
			<!-- Add Pagination -->
			<div class="container">
				<div class="row align-items-center">
					<div class="col-md-6">
						<h3 class="shadepro-testimonial-title"><?php echo $settings['testimonial_title'] ?></h3>
					</div>
					<div class="col-md-6 text-md-right">
						<div class="swiper-navigation">
							<button class="swipe-prev" type="button"><img src="<?php echo plugins_url( '../assets/img/arrow.svg', __FILE__ ) ?>" alt="swiper0icon"></button>
							<button class="swipe-next" type="button"><img src="<?php echo plugins_url( '../assets/img/arrow.svg', __FILE__ ) ?>" alt="swiper0icon"></button>
						</div>
					</div>
				</div>
			</div>

			<div class="shadepro-testimonial-wrapper swiper-wrapper">
				<?php foreach($settings['testimonial'] as  $testimonial):  ?>
					<div class="shadepro-testimonial-item swiper-slide">
						<div class="shadepro-testimonial-header">
							<div class="shadepro-customer-image">
								<img src="<?php echo $testimonial['image']['url'] ?>" alt="">
							</div>
							<h4><?php echo $testimonial['name'] ?></h4>
							<span><?php echo $testimonial['title'] ?></span>
						</div>
						<div class="shadepro-testimonial-content">
							<p><?php echo esc_html( $testimonial['content'] ) ?></p>
							<div class="testimonial-star">
								<?php for($i=0;$i<$testimonial['star'];$i++): ?>
									<i class="fa fa-star"></i>
								<?php endfor; ?>
							</div>
						</div>
					</div>
				<?php endforeach;  ?>
			</div>
		</div>
		  <!-- Initialize Swiper -->
		  <script>
			  jQuery(document).ready(function(){
				var swiper = new Swiper('.shadepro-testimonial-carousel', {
					slidesPerView: 3,
					spaceBetween: 50,
					centeredSlides: true,
					navigation: {
						nextEl: '.swipe-next',
						prevEl: '.swipe-prev',
					},
					breakpoints: {
						0: {
						slidesPerView: <?php echo $settings['slide_perview_mobile'] ?>
						},
						700: {
						slidesPerView: <?php echo $settings['slide_perview_tablet'] ?>
						},
						1024: {
						slidesPerView: <?php echo $settings['slide_perview_desktop'] ?>
						},
						1800: {
						slidesPerView: <?php echo $settings['slide_perview_extra_large'] ?>
						},
					}

				});

			  })
		</script>
		<?php endif; ?>
		<?php
	}

}

