<?php


/**
 * Elementor oEmbed Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class ShadeProPriceTable extends \Elementor\Widget_Base
{

	/**
	 * Get widget name.
	 *
	 * Retrieve oEmbed widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name()
	{
		return 'shadepro-price-table';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve oEmbed widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title()
	{
		return __('ShadePro Pricing Loop', 'shadepro-ts');
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve oEmbed widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon()
	{
		return 'eicon-price-table';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the oEmbed widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories()
	{
		return ['shadepro-addons'];
	}

	/**
	 * Register oEmbed widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls()
	{

		/**
		 * Content tab
		 */
		$this->start_controls_section(
			'price_tabs',
			[
				'label' => __('Price Tabs', 'shadepro-ts'),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'first_tab_title',
			[
				'label' => __('First tab title', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html('Monthly '),
			]
		);
		$this->add_control(
			'second_tab_title',
			[
				'label' => __('Second tab title', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html('Yearly '),
			]
		);
		$this->add_control(
			'price_offer',
			[
				'label' => __('Offer text', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html('Save 20% '),
			]
		);
		$this->end_controls_section();


		$this->start_controls_section(
			'price_tables',
			[
				'label' => __('Price tables', 'shadepro-ts'),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'only_features',
			[
				'label' => __('Show Only Features', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __('No', 'shadepro-ts'),
				'label_off' => __('yes', 'shadepro-ts'),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);

		$repeater->add_control(
			'focused',
			[
				'label' => __('Make it focsed', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __('Not Focused', 'shadepro-ts'),
				'label_off' => __('Focused', 'shadepro-ts'),
				'return_value' => 'focused',
				'condition'	=> [
					'only_features' => 'no',
				]
			]
		);

		$repeater->add_control(
			'title',
			[
				'label' => __('Price title', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => 'Personal',
				'condition'	=> [
					'only_features' => 'no',
				]
			]
		);

		$repeater->add_control(
			'price_currency',
			[
				'label' => __('Price Currency', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __('$', 'shadepro-ts'),
				'condition'	=> [
					'only_features' => 'no',
				]
			]
		);

		$repeater->add_control(
			'price_monthly',
			[
				'label' => __('Montly Price', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __('99', 'shadepro-ts'),
				'condition'	=> [
					'only_features' => 'no',
				]
			]
		);
		$repeater->add_control(
			'price_duration_monthly',
			[
				'label' => __('Montly Price Duration text', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __('per month', 'shadepro-ts'),
				'condition'	=> [
					'only_features' => 'no',
				]
			]
		);
		$repeater->add_control(
			'price_subtitle_monthly',
			[
				'label' => __('Montly Price Subtitle', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __('billed monthly', 'shadepro-ts'),
				'condition'	=> [
					'only_features' => 'no',
				]
			]
		);

		$repeater->add_control(
			'price_yearly',
			[
				'label' => __('Yearly  Price', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __('180', 'shadepro-ts'),
				'condition'	=> [
					'only_features' => 'no',
				]
			]
		);
		$repeater->add_control(
			'price_duration_yearly',
			[
				'label' => __('Yearly Price Duration text', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __('per year', 'shadepro-ts'),
				'condition'	=> [
					'only_features' => 'no',
				]
			]
		);
		$repeater->add_control(
			'price_subtitle_yearly',
			[
				'label' => __('Montly Price Yearly', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __('billed Yearly', 'shadepro-ts'),
				'condition'	=> [
					'only_features' => 'no',
				]
			]
		);

		$repeater->add_control(
			'features',
			[
				'label' => __('Features', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::WYSIWYG,
			]
		);

		$repeater->add_control(
			'show_btn',
			[
				'label' => __('Show Button', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __('Show', 'shadepro-ts'),
				'label_off' => __('Hide', 'shadepro-ts'),
				'default'	=> 'true',
				'return_value' => 'true',
			]
		);
		$repeater->add_control(
			'btn_icon',
			[
				'label' => __('Button Icon', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => '',
					'library' => '',
				],
				'condition' => [
					'show_btn' => 'true',
				]
			]
		);
		$repeater->add_control(
			'button_label',
			[
				'label' => __('Button text', 'shadepro-ts'),
				'type' =>  \Elementor\Controls_Manager::TEXTAREA,
				'default' => 'Learn More',
				'condition' => [
					'show_btn' => 'true',
				]
			]
		);

		$repeater->add_control(
			'button_url',
			[
				'label' => __('Button URL', 'shadepro-ts'),
				'type' =>  \Elementor\Controls_Manager::URL,
				'condition' => [
					'show_btn' => 'true',
				]
			]

		);
		$repeater->add_control(
			'btn_style',
			[
				'label' => __('Button  Style', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'boxed',
				'options' => [
					'inline'  => __('Inline', 'shadepro-ts'),
					'boxed' => __('Boxed', 'shadepro-ts'),
				],
			]
		);
		$repeater->add_control(
			'bottom_info',
			[
				'label' => __('Bottom Info', 'shadepro-ts'),
				'type' =>  \Elementor\Controls_Manager::TEXTAREA,
				'default' => 'No credit card required',
			]
		);
		$this->add_control(
			'pricing_list',
			[
				'label' => __('Repeater List', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'title_field' => '{{{ title }}}',
			]
		);

		$this->end_controls_section();

		/**
		 * Style tab
		 */
		$this->start_controls_section(
			'pricing_tabs_tyle',
			[
				'label' => __('Pricing Tabs', 'shadepro-ts'),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'tabs_title_typo',
				'label' => __('Title typography', 'shadepro-ts'),
				'selector' => '{{WRAPPER}} .first-tabs-title,{{WRAPPER}} .second-tabs-title',
			]
		);
		$this->add_control(
			'tabs_title_color',
			[
				'label' => __('Title Color', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .first-tabs-title, {{WRAPPER}} .second-tabs-title' => 'color: {{VALUE}}',
				]
			]
		);
		$this->add_control(
			'offer_divide',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'offer_typo',
				'label' => __('Offer typography', 'shadepro-ts'),
				'selector' => '{{WRAPPER}} .shadepro-price-offer',
			]
		);
		$this->add_control(
			'offer_color',
			[
				'label' => __('Offer Color', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .shadepro-price-offer' => 'color: {{VALUE}}',
				]
			]
		);
		$this->add_control(
			'offer_bg_color',
			[
				'label' => __('Offer Background Color', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .shadepro-price-offer' => 'background-color: {{VALUE}}',
				]
			]
		);
		$this->add_responsive_control(
			'offer_padding',
			[
				'label' => __('Offer Text Padding', 'plugin-name'),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors' => [
					'{{WRAPPER}} .shadepro-price-offer' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'offer_radius',
			[
				'label' => __('Offer Text Radius', 'plugin-name'),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors' => [
					'{{WRAPPER}} .shadepro-price-offer' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		$this->start_controls_section(
			'Title_style',
			[
				'label' => __('Title', 'shadepro-ts'),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'title_typo',
				'label' => __('Title typography', 'shadepro-ts'),
				'selector' => '{{WRAPPER}} .shadepro-pricing-title',
			]
		);
		$this->add_control(
			'title_color',
			[
				'label' => __('Title Color', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .shadepro-pricing-title' => 'color: {{VALUE}}',
				]
			]
		);
		$this->end_controls_section();
		$this->start_controls_section(
			'price_style',
			[
				'label' => __('Price', 'shadepro-ts'),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'price_typo',
				'label' => __('Price typography', 'shadepro-ts'),
				'selector' => '{{WRAPPER}} .shadepro-pricing-area .shadepro-pricing-item .shadepro-price h2',
			]
		);
		$this->add_control(
			'price_color',
			[
				'label' => __('Price Color', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .shadepro-pricing-area .shadepro-pricing-item .shadepro-price h2' => 'color: {{VALUE}}',
				]
			]
		);
		$this->add_control(
			'dura_style_divider',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'price_dur_typo',
				'label' => __('Price Duration typography', 'shadepro-ts'),
				'selector' => '{{WRAPPER}} .shadepro-price span.shadepro-pricing-duration',
			]
		);

		$this->add_control(
			'duration_color',
			[
				'label' => __('Duration Color', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .shadepro-pricing-duration' => 'color: {{VALUE}}',
				]
			]
		);

		$this->end_controls_section();
		$this->start_controls_section(
			'feature_style',
			[
				'label' => __('Feature', 'shadepro-ts'),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'features_typo',
				'label' => __('Features typography', 'shadepro-ts'),
				'selector' => '{{WRAPPER}} .shadepro-pricing-features',
			]
		);

		$this->add_control(
			'features_color',
			[
				'label' => __('Features Color', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .shadepro-pricing-features' => 'color: {{VALUE}}',
				]
			]
		);


		$this->end_controls_section();
		$this->start_controls_section(
			'button_style',
			[
				'label' => __('Button', 'shadepro-ts'),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'button_typo',
				'label' => __('Button typography', 'shadepro-ts'),
				'selector' => '{{WRAPPER}} .shadepro-btn-wrapper .shadepro-btn',
			]
		);

		$this->add_control(
			'btn_color',
			[
				'label' => __('Button Color', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .shadepro-btn-wrapper .shadepro-btn' => 'color: {{VALUE}}',
				]
			]
		);

		$this->add_control(
			'btn_bg_color',
			[
				'label' => __('Button Background Color', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .shadepro-btn-wrapper .shadepro-btn' => 'background-color: {{VALUE}}',
				]
			]
		);
		$this->add_responsive_control(
			'button_padding',
			[
				'label' => __('Button Padding', 'plugin-name'),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'default'	=>	[
					'top' => '40px',
					'right' => '15px',
					'bottom' => '40px',
					'left' => '15px'
				],
				'selectors' => [
					'{{WRAPPER}} .shadepro-btn.btn-type-boxed' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		$this->start_controls_section(
			'bottom_text',
			[
				'label' => __('Bottom Info', 'shadepro-ts'),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'bottom_typo',
				'label' => __('typography', 'shadepro-ts'),
				'selector' => '{{WRAPPER}} .pricing-bottom-info',
			]
		);

		$this->add_control(
			'bottom_info_olor',
			[
				'label' => __('Color', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pricing-bottom-info' => 'color: {{VALUE}}',
				]
			]
		);
		$this->end_controls_section();
		$this->start_controls_section(
			'Box',
			[
				'label' => __('Box', 'shadepro-ts'),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_control(
			'box_bg_color',
			[
				'label' => __('Box Background Color', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .shadepro-pricing-item' => 'background-color: {{VALUE}}',
				]
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'box_shadow',
				'label' => __('Foucsed Box Shadow', 'shadepro-ts'),
				'selector' => '{{WRAPPER}} .shadepro-pricing-item.focused',
				'fields_options' =>
				[
					'box_shadow_type' =>
					[
						'default' => 'yes'
					],
					'box_shadow' => [
						'default' =>
						[
							'horizontal' => 3,
							'vertical' => 67,
							'blur' => 99,
							'spread' => 0,
							'color' => ' rgba(111, 118, 138, 0.16)'
						]
					]
				],

			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'box_border',
				'label' => __( 'box_border', 'shadepro-ts' ),
				'selector' => '{{WRAPPER}} .shadepro-pricing-item',
			]
		);
		$this->add_responsive_control(
			'box_radius',
			[
				'label' => __('Box Radius', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors' => [
					'{{WRAPPER}} .shadepro-pricing-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'box_padding',
			[
				'label' => __('Box Padding', 'plugin-name'),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors' => [
					'{{WRAPPER}} .shadepro-pricing-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render oEmbed widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render()
	{
		$popular_post_key = array();
		$popular_meta_value_num = array();
		$settings = $this->get_settings_for_display();
?>

		<?php if ($settings['pricing_list']) : ?>
			<div class="shadepro-pricing-area pricing-style-classic">
				<div class="container-fluid">
					<div class="row">
						<div class="col-12 text-center">
							<div class="shadepro-pricing-tabs">

								<span class="first-tabs-title"><?php echo $settings['first_tab_title'] ?></span>
								<div class="shadepro-price-tabs-switcher">
									<div id="pricing-dynamic-deck--head">
										<a href="javascript:" class="btn-toggle active mx-3" data-pricing-trigger data-target="#shadepro-dynamic-deck"><span class="round"></span></a>
									</div>
								</div>
								<span class="second-tabs-title"><?php echo $settings['second_tab_title'] ?></span>

								<span class="shadepro-price-offer"><?php echo $settings['price_offer'] ?></span>
							</div>
						</div>
					</div>
					<div class="row justify-content-center" id="shadepro-dynamic-deck" data-pricing-dynamic data-value-active="monthly">
						<?php
						$i = 0;
						foreach ($settings['pricing_list'] as  $pricing) :
							$i++;

						?>
							<div class="col-xl-4 col-md-6 shadepro-pricing-item-wrap">
								<div class="shadepro-pricing-item <?php echo $pricing['focused'] ?>">
									<!-- classic pricing -->
									<?php if ('no' == $pricing['only_features']) : ?>
										<div class="shadepro-price-wrap">
											<span class="shadepro-pricing-title"><?php echo $pricing['title'] ?></span>
											<div class="shadepro-price shadepro-price-monthly">
												<h2 class="dynamic-value" data-active="<?php echo $pricing['price_monthly'] ?>" data-monthly="<?php echo $pricing['price_monthly'] ?>" data-yearly="<?php echo $pricing['price_yearly'] ?>"><span class="price-currency"><?php echo esc_html( $pricing['price_currency'] ) ?></span></h2>
											<span class="shadepro-pricing-duration dynamic-value" data-active="<?php echo $pricing['price_duration_monthly'] ?>" data-monthly="<?php echo $pricing['price_duration_monthly'] ?>" data-yearly="<?php echo $pricing['price_duration_yearly'] ?>"></span>
											<span class="price-subtitle dynamic-value" data-active="<?php echo esc_attr($pricing['price_subtitle_monthly'])?>" data-monthly="<?php echo esc_attr($pricing['price_subtitle_monthly'])?>" data-yearly="<?php echo esc_attr($pricing['price_subtitle_yearly'])?>"></span>
											</div>
										</div><!--  end of shadepro-price-wrap  -->
									<?php else : ?>
										<div class="shadepro-pricing-head-filler"></div>
									<?php endif; ?>
									<div class="shadepro-pricing-features">
										<?php echo $pricing['features'] ?>
									</div>
									<!-- minimal pricing -->
									<?php if ('true' == $pricing['show_btn']) : ?>
										<div class="shadepro-btn-wrapper">
											<a class="shadepro-btn btn-type-<?php echo $pricing['btn_style'] ?> " href="<?php echo $pricing['button_url']['url'] ?>"><?php echo $pricing['button_label'] ?> <?php \Elementor\Icons_Manager::render_icon($pricing['btn_icon'], ['aria-hidden' => 'true']); ?></a>
										</div>
									<?php endif; ?>
									<?php if('' != $pricing['bottom_info']){printf('<span class="pricing-bottom-info">%s</span>', $pricing['bottom_info']);} ?>
								</div>
							</div>
						<?php endforeach;  ?>
					</div>
				</div>
			</div>
		<?php endif; ?>
<?php
	}
}
