(function ($) {

    "use strict";
  /* ---------------------------------------------
    CountDown
    --------------------------------------------- */
    function countDown() {
        var second = 1000,
            minute = second * 60,
            hour = minute * 60,
            day = hour * 24;

        var shadeproDate = $(".shadepro-countdown#date").data("date");
        var countDown = new Date(shadeproDate).getTime(),
            x = setInterval(function () {
                var now = new Date().getTime(),
                    distance = countDown - now;
                var cDays = document.getElementById("days");
                if (cDays) {
                    (document.getElementById("days").innerText = addZero(Math.floor(distance / day)),
                        (document.getElementById("hours").innerText = addZero(Math.floor(
                            (distance % day) / hour
                        ), 2))),
                    (document.getElementById("minutes").innerText = addZero(Math.floor(
                        (distance % hour) / minute
                    ), 2)),
                    (document.getElementById("seconds").innerText = addZero(Math.floor(
                        (distance % minute) / second
                    ), 2));
                }
            }, second);
    }

    function addZero(your_number, length) {
        var num = '' + your_number;
        while (num.length < length) {
            num = '0' + num;
        }
        return num;
    }
  
    /* ---------------------------------------------

    Navigation menu

    --------------------------------------------- */

    // dropdown for mobile

    $(document).ready(function () {
        countDown();
        if($.fn.datepicker){
            $('#coworking-date').datepicker();
        }

        $("[data-pricing-trigger]").on("click",function(e){
            $(e.target).toggleClass("active");
            var target = $(e.target).attr("data-target");
            console.log($(target).attr("data-value-active") == "monthly");
             if($(target).attr("data-value-active") == "monthly"){
                   $(target).attr("data-value-active","yearly");
             }else{
                   $(target).attr("data-value-active","monthly");
             }
        })

        // Classic tab switcher
        $("[data-pricing-tab-trigger]").on("click",function(e){
            $('[data-pricing-tab-trigger]').removeClass("active");
            $(this).addClass("active");
            var target = $(e.target).attr("data-target");
            console.log($(target).attr("data-value-active") == "monthly");
             if($('.tab-monthly').hasClass('active')){
                   $(target).attr("data-value-active","monthly");
             }else{
                   $(target).attr("data-value-active","yearly");
             }
        })


    
    });

    $(window).load(function(){
        var cPriceHeadHeight = $('.pricing-style-classic .shadepro-price-wrap').height();
        var mPriceHeadHeight = $('.pricing-style-minimal .shadepro-price-wrap').height();
        $('.pricing-style-classic .shadepro-pricing-head-filler').css("height",  cPriceHeadHeight+"px");
        $('.pricing-style-minimal .shadepro-pricing-head-filler').css("height",  mPriceHeadHeight+"px");
    })

    var ShadeProductCategories = function(){
        if($.fn.isotope){
            var $gridMas = $('.product-categories-wrap.masonry');            

            $gridMas.isotope({
                itemSelector: '.shade-product-cat-wrap',
                percentPosition: true,
                layoutMode: 'packery',
            })
            
            $gridMas.imagesLoaded().progress(function () {
                $gridMas.isotope({
                    itemSelector: '.shade-product-cat-wrap',
                    percentPosition: true,
                    layoutMode: 'packery',
    
                })
            });
        }


    }
    var ShadeSearch = function(){
        if($.fn.niceSelect){
            // $('#job-location, #cowork-location').niceSelect();
        }
    }
    var ShadeJobLoop = function(){
        if($.fn.owlCarousel){
            $('.shade-job-carousel').owlCarousel({
                margin:30,
                responsiveClass:true,
                navText: ['<i class="fas fa-arrow-left"></i>', '<i class="fas fa-arrow-right"></i>'],
                responsive:{
                    0:{
                        items:1,
                        nav:true
                    },
                    768:{
                        items:2,
                        nav:false
                    },
                    1000:{
                        items:4,
                        nav:true,
                        loop:false
                    }
                }
            })
        }
    }
    $(window).on("elementor/frontend/init", function () {

        elementorFrontend.hooks.addAction("frontend/element_ready/shadepro-product-categories.default", ShadeProductCategories);
        elementorFrontend.hooks.addAction("frontend/element_ready/shadepro-job-search.default", ShadeSearch);
        elementorFrontend.hooks.addAction("frontend/element_ready/shadepro-cowork-search.default", ShadeSearch);
        elementorFrontend.hooks.addAction("frontend/element_ready/shadepro-job-loop.default", ShadeJobLoop);


    });

})(jQuery);
