<?php

/**
 * Plugin Name: ShadePro Helper
 * Description: This plugin is compatible with ShadePro WordPress Landing Page Theme
 * Plugin URI: http://themes.dhrubok.website/xpider
 * Version:     1.0.0
 * Author:      Ashraf
 * Author URI:  https://grayic.com
 * Text Domain: shadepro-ts
 */

if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly.
}

/**
 * Main shadepro-ts Class
 *
 * The main class that initiates and runs the plugin.
 *
 * @since 1.0.0
 */
final class shadepro_elementor
{

	/**
	 * Plugin Version
	 *
	 * @since 1.0.0
	 *
	 * @var string The plugin version.
	 */
	const VERSION = '1.0.0';

	/**
	 * Minimum Elementor Version
	 *
	 * @since 1.0.0
	 *
	 * @var string Minimum Elementor version required to run the plugin.
	 */
	const MINIMUM_ELEMENTOR_VERSION = '2.0.0';

	/**
	 * Minimum PHP Version
	 *
	 * @since 1.0.0
	 *
	 * @var string Minimum PHP version required to run the plugin.
	 */
	const MINIMUM_PHP_VERSION = '5.6';

	/**
	 * Instance
	 *
	 * @since 1.0.0
	 *
	 * @access private
	 * @static
	 *
	 * @var shadepro_elementor The single instance of the class.
	 */
	private static $_instance = null;

	/**
	 * Instance
	 *
	 * Ensures only one instance of the class is loaded or can be loaded.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 * @static
	 *
	 * @return shadepro_elementor An instance of the class.
	 */
	public static function instance()
	{

		if (is_null(self::$_instance)) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	/**
	 * Constructor
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function __construct()
	{

		add_action('init', [$this, 'i18n']);
		add_action('plugins_loaded', [$this, 'init']);
	}

	/**
	 * Load Textdomain
	 *
	 * Load plugin localization files.
	 *
	 * Fired by `init` action hook.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function i18n()
	{

		load_plugin_textdomain('shadepro-ts');
	}

	/**
	 * Initialize the plugin
	 *
	 * Load the plugin only after Elementor (and other plugins) are loaded.
	 * Checks for basic plugin requirements, if one check fail don't continue,
	 * if all check have passed load the files required to run the plugin.
	 *
	 * Fired by `plugins_loaded` action hook.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function init()
	{
		// Require the main plugin file
		require_once(__DIR__ . '/inc/shadepro-custom-post-types.php');
		// require_once(__DIR__ . '/shadepro-recent-post.php');
		require_once(__DIR__ . '/inc/shadepro-shortcodes.php');
		require(__DIR__ . '/inc/shadepro-helper-functions.php');
		require(__DIR__ . '/inc/elementor-helper.php');
		require(__DIR__ . '/inc/ShadeProNavWalker.php');
		if (class_exists('woocommerce')) {
			require_once(__DIR__ . '/inc/woocommerce.php');
		}

		// Check if Elementor installed and activated
		if (!did_action('elementor/loaded')) {
			add_action('admin_notices', [$this, 'admin_notice_missing_main_plugin']);
			return;
		}

		// Check for required Elementor version
		if (!version_compare(ELEMENTOR_VERSION, self::MINIMUM_ELEMENTOR_VERSION, '>=')) {
			add_action('admin_notices', [$this, 'admin_notice_minimum_elementor_version']);
			return;
		}

		// Check for required PHP version
		if (version_compare(PHP_VERSION, self::MINIMUM_PHP_VERSION, '<')) {
			add_action('admin_notices', [$this, 'admin_notice_minimum_php_version']);
			return;
		}

		// Add Plugin actions
		add_action('elementor/widgets/widgets_registered', [$this, 'init_widgets']);
		add_action('elementor/frontend/after_enqueue_styles', [$this, 'widget_styles']);
		add_action('elementor/frontend/after_register_scripts', [$this, 'widget_scripts']);
	}
	/**
	 * Admin notice
	 *
	 * Warning when the site doesn't have Elementor installed or activated.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function admin_notice_missing_main_plugin()
	{

		if (isset($_GET['activate'])) unset($_GET['activate']);

		$message = sprintf(
			/* translators: 1: Plugin name 2: Elementor */
			esc_html__('"%1$s" requires "%2$s" to be installed and activated.', 'shadepro-ts'),
			'<strong>' . esc_html__('shadepro-ts', 'shadepro-ts') . '</strong>',
			'<strong>' . esc_html__('Elementor', 'shadepro-ts') . '</strong>'
		);

		printf('<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message);
	}

	/**
	 * Admin notice
	 *
	 * Warning when the site doesn't have a minimum required Elementor version.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function admin_notice_minimum_elementor_version()
	{

		if (isset($_GET['activate'])) unset($_GET['activate']);

		$message = sprintf(
			/* translators: 1: Plugin name 2: Elementor 3: Required Elementor version */
			esc_html__('"%1$s" requires "%2$s" version %3$s or greater.', 'shadepro-ts'),
			'<strong>' . esc_html__('ShadePro Helper', 'shadepro-ts') . '</strong>',
			'<strong>' . esc_html__('Elementor', 'shadepro-ts') . '</strong>',
			self::MINIMUM_ELEMENTOR_VERSION
		);

		printf('<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message);
	}

	/**
	 * Admin notice
	 *
	 * Warning when the site doesn't have a minimum required PHP version.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function admin_notice_minimum_php_version()
	{

		if (isset($_GET['activate'])) unset($_GET['activate']);

		$message = sprintf(
			/* translators: 1: Plugin name 2: PHP 3: Required PHP version */
			esc_html__('"%1$s" requires "%2$s" version %3$s or greater.', 'shadepro-ts'),
			'<strong>' . esc_html__('shadepro-ts', 'shadepro-ts') . '</strong>',
			'<strong>' . esc_html__('PHP', 'shadepro-ts') . '</strong>',
			self::MINIMUM_PHP_VERSION
		);

		printf('<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message);
	}

	/**
	 * Init Widgets
	 *
	 * Include widgets files and register them
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function init_widgets()
	{

		// Include Widget files
		// require_once(__DIR__ . '/widgets/hero-area.php');
		require_once(__DIR__ . '/widgets/btn.php');
		require_once(__DIR__ . '/widgets/feature-box.php');
		require_once(__DIR__ . '/widgets/inline-icon-box.php');
		require_once(__DIR__ . '/widgets/pricing-box.php');
		require_once(__DIR__ . '/widgets/post-loop.php');
		require_once(__DIR__ . '/widgets/main-menu.php');
		require_once(__DIR__ . '/widgets/logo.php');
		require_once(__DIR__ . '/widgets/page-title.php');
		require_once(__DIR__ . '/widgets/pricing-table.php');
		require_once(__DIR__ . '/widgets/team-loop.php');
		require_once(__DIR__ . '/widgets/job-search.php');
		require_once(__DIR__ . '/widgets/job-categories.php');
		require_once(__DIR__ . '/widgets/job-loop.php');
		require_once(__DIR__ . '/widgets/testimonial-simple.php');
		require_once(__DIR__ . '/widgets/service-loop.php');
		require_once(__DIR__ . '/widgets/co-working-search.php');
		if (class_exists('woocommerce')) {
			require_once(__DIR__ . '/widgets/product-categories.php');
			require_once(__DIR__ . '/widgets/mini-cart.php');
			require_once(__DIR__ . '/widgets/cart-count.php');
			require_once(__DIR__ . '/widgets/products.php');
		}
		// require_once(__DIR__ . '/widgets/testimonial-carousel.php');
		// require_once(__DIR__ . '/widgets/testimonial-stories.php');
		// require_once(__DIR__ . '/widgets/integrated-icon.php');
		// require_once(__DIR__ . '/widgets/doctor-box.php');
		// require_once(__DIR__ . '/widgets/newsletter-form.php');
		// require_once(__DIR__ . '/widgets/job-list.php');
		// require_once(__DIR__ . '/widgets/count-down.php');

		// Register widget
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \ShadeProBtn());
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \ShadeProFeatureBox());
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \ShadeProInlineIconBox());
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \ShadeProPricingBox());
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \ShadeProBlogLoop());
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \ShadeProMainMenu());
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \ShadeProPageTitle());
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \ShadeProSiteLogo);
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \ShadeProPriceTable());
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \ShadeProTeamLoop());
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \ShadeJobSearch());
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \ShadeProJobCat());
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \ShadeProJobLoop());
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \ShadeProTestimonial());
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \ShadeProServiceLoop());
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \ShadeCoWOrkSearch());
		if (class_exists('woocommerce')) {
			\Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \ShadeProProductCat());
			\Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \ShadeProCartCount());
			\Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \ShadeProMiniCart());
			\Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \ShadeProProducts());
		}






		// \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \ShadeProHeroArea());
		// \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \ShadeProTestimonialStories());
		// \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \ShadeProTestimonialCarousel());
		// \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \ShadeProIntegratedIcons());
		// \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \ShadeProDoctorBox());
		// \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \ShadeProNewsLetterForm());
		// \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \ShadeProJobList());
		// \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \ShadeProCountDown());

	}


	public function widget_styles()
	{
		wp_dequeue_style( 'elementor-animations' );


		wp_enqueue_style('shade-elementor-animations', plugins_url('/assets/css/animate.css', __FILE__), [], microtime());
		wp_enqueue_style('owl-carousel', plugins_url('/assets/css/owl.carousel.min.css', __FILE__), [], microtime());
		wp_enqueue_style('shadepro-addons', plugins_url('/assets/css/addons.css', __FILE__), [], microtime());
	}
	public function widget_scripts()
	{
		wp_enqueue_script( 'jquery-ui-datepicker' );
		wp_enqueue_script('owl-carousel', plugins_url('/assets/js/owl.carousel.min.js', __FILE__), ['jquery']);
		wp_enqueue_script('isotope', plugins_url('/assets/js/isotope.pkgd.min.js', __FILE__), ['jquery']);
		wp_enqueue_script('packery', plugins_url('/assets/js/packery-mode.pkgd.min.js', __FILE__), ['jquery', 'isotope']);
		wp_enqueue_script('imagesloaded', plugins_url('/assets/js/imagesloaded.pkgd.min.js', __FILE__), ['jquery', 'isotope']);
		wp_enqueue_script('shadepro-addon', plugins_url('/assets/js/addon.js', __FILE__), ['jquery']);
	}
}

shadepro_elementor::instance();


/**
 * adding new category
 */
function shadepro_add_elementor_widget_categories($elements_manager)
{

	$elements_manager->add_category(
		'shadepro-addons',
		[
			'title' => __('ShadePro addons', 'shadepro-ts'),
			'icon' => 'fa fa-plug',
		]
	);
}
add_action('elementor/elements/categories_registered', 'shadepro_add_elementor_widget_categories');








// Adding Circular Std Font
/**
 * Add Font Group
 */
add_filter('elementor/fonts/groups', function ($font_groups) {
	$font_groups['shadepro_fonts'] = __('ShadePro Fonts');
	return $font_groups;
});

add_filter('elementor/fonts/additional_fonts', function ($additional_fonts) {
	$additional_fonts['Circular Std'] = 'shadepro_fonts';
	return $additional_fonts;
});
