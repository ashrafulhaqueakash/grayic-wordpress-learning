<?php
if (!defined('ABSPATH')) {
    exit;
}
// Exit if accessed directly

/**
 * Elementor Hello World
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class ShadeProProductCat extends \Elementor\Widget_Base
{

    /**
     * Retrieve the widget name.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name()
    {
        return 'shadepro-product-categories';
    }


    /**
     * Retrieve the widget title.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title()
    {
        return __('ShadePro Product Categories', 'shadpro-ts');
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon()
    {
        return 'eicon-image';
    }

    /**
     * Retrieve the list of categories the widget belongs to.
     *
     * Used to determine where to display the widget in the editor.
     *
     * Note that currently Elementor supports only one category.
     * When multiple categories passed, Elementor uses the first one.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories()
    {
        return ['shadpro-addons'];
    }

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function _register_controls()
    {
        $this->start_controls_section(
            'section_layout',
            [
                'label' => __('General', 'shadepro-ts'),
            ]
        );
        $this->add_control(
            'layout_type',
            [
                'label' => __('Layout type', 'shadepro-ts'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => array(
                    'masonry' => 'Masonry',
                    'normal' => 'Normal',
                ),
                'default' => 'masonry',
            ]
        );
        $this->add_control(
            'category_count',
            [
                'label' => __('Category Limit', 'shadepro-ts'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 6,
            ]
        );

        $this->add_control(
            'use_custom_height',
            [
                'label' => __('Use custom height?', 'shadepro-ts'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'shadepro-ts'),
                'label_off' => __('No', 'shadepro-ts'),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );

        $this->add_responsive_control(
            'normal_image_height',
            [
                'label' => __('Normal Image Height', 'shadepro-ts'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'devices' => ['desktop', 'tablet', 'mobile'],
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}}  .shade-product-cat' => 'height: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'use_custom_height' => 'yes'
                ],
            ]
        );

        $this->end_controls_section();
        $this->start_controls_section(
            'section_style',
            [
                'label' => __('Title', 'shadepro-ts'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'label' => __('Title Typography', 'shadepro-ts'),
                'name' => 'title_typo',
                'selector' => '{{WRAPPER}} .shade-product-cat .product-cat-title',
            ]
        );
        $this->add_control(
            'title_color',
            [
                'label' => __('Title Color', 'shadepro-ts'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .shade-product-cat .product-cat-title' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'title_gap',
            [
                'label' => __('Title gap', 'shadepro-ts'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 400,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}}  .shade-product-cat .product-cat-title .product-count' => 'margin-top:{{SIZE}}{{UNIT}};',


                ],
            ]
        );
        $this->end_controls_section();
        $this->start_controls_section(
            'section_subtitle',
            [
                'label' => __('Subtitle', 'shadepro-ts'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'label' => __('Title Typography', 'shadepro-ts'),
                'name' => 'subtitle_typo',
                'selector' => '{{WRAPPER}} .shade-product-cat .product-cat-title .product-count',
            ]
        );
        $this->add_control(
            'subtitle_color',
            [
                'label' => __('Color', 'shadepro-ts'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .shade-product-cat .product-cat-title .product-count' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'subtitle_gap',
            [
                'label' => __('Title gap', 'shadepro-ts'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 400,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}}  .shade-product-cat .product-cat-title ' => 'margin-bottom:{{SIZE}}{{UNIT}};',


                ],
            ]
        );
        $this->end_controls_section();
        $this->start_controls_section(
            'section_box_style',
            [
                'label' => __('Box', 'shadepro-ts'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_responsive_control(
            'box_padding',
            [
                'label' => __('Padding', 'shadepro-ts'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .shade-product-cat ' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'box_radikus',
            [
                'label' => __('Border Radius', 'shadepro-ts'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .shade-product-cat ' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();
    }
    /**
     * Render the widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function render()
    {

        $settings = $this->get_settings();

        $taxonomy     = 'product_cat';
        $orderby      = 'date';
        $show_count   = 1; 
        $pad_counts   = 0; 
        $hierarchical = 0; 
        $title        = '';
        $empty        = 1;

        $args = array(
            'taxonomy'     => $taxonomy,
            'orderby'      => $orderby,
            'show_count'   => $show_count,
            'pad_counts'   => $pad_counts,
            'hierarchical' => $hierarchical,
            'title_li'     => $title,
            'hide_empty'   => $empty,
            'number'       => $settings['category_count']+1
        );
        $all_categories = get_categories($args);
?>
        <div class="product-categories-wrap <?php echo esc_attr($settings['layout_type']) ?> row">
            <?php
            foreach ($all_categories as $cat) {
                $category_id = $cat->term_id;
                $thumbnail_id = get_term_meta($category_id, 'thumbnail_id', true);
                $image = wp_get_attachment_url($thumbnail_id);
                $product_count_label = _nx('Item', 'Items', $cat->category_count, 'Item', 'shadepro-ts');
                $list = '';
                if ($image) {?>
                    
                    <div class="col-lg-4 col-md-6 shade-product-cat-wrap">
                        <div class="shade-product-cat">
                            <a href="<?php echo get_term_link($cat->slug, 'product_cat') ?>">
                                <div class="product-cat-title"><?php echo $cat->name ?>
                                    <span class="product-count"> <?php echo $cat->category_count ?> <?php echo $product_count_label ?></span>
                                </div>
                                <img src="<?php echo $image ?>" alt="<?php echo $cat->name ?>"/></a>
                        </div>
                    </div>
              <?php  }


            } ?>

        </div>
<?php
    }
}
