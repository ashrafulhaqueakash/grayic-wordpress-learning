<?php

/**
 * Elementor oEmbed Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class ShadeProBtn extends \Elementor\Widget_Base
{

    /**
     * Get widget name.
     *
     * Retrieve oEmbed widget name.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name()
    {
        return 'shadepro-btn';
    }

    /**
     * Get widget title.
     *
     * Retrieve oEmbed widget title.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title()
    {
        return __('ShadePro Button', 'shadepro-ts');
    }

    /**
     * Get widget icon.
     *
     * Retrieve oEmbed widget icon.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon()
    {
        return 'eicon-button';
    }

    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the oEmbed widget belongs to.
     *
     * @since 1.0.0
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories()
    {
        return ['shadepro-addons'];
    }

    /**
     * Register oEmbed widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function _register_controls()
    {

        /**
         * Content tab
         */
        $this->start_controls_section(
            'button',
            [
                'label' => __('Button', 'shadepro-ts'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'button_type',
            [
                'label' => __('Button Style', 'shadepro-ts'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'inline',
                'options' => [
                    'inline' => __('Inline', 'shadepro-ts'),
                    'boxed' => __('Boxed', 'shadepro-ts'),
                ],
            ]
        );
        $this->add_control(
            'enable_lightbox',
            [
                'label' => __('Youtube Video Popup', 'shadepro-ts'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'shadepro-ts'),
                'label_off' => __('No', 'shadepro-ts'),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );

        $this->add_control(
            'button_label',
            [
                'label' => __('Button text', 'shadepro-ts'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => 'Learn More',
            ]
        );

        $this->add_control(
            'button_url',
            [
                'label' => __('Button URL', 'shadepro-ts'),
                'type' => \Elementor\Controls_Manager::URL,
            ]
        );

        $this->add_control(
            'icon',
            [
                'label' => __('Icon', 'shadepro-ts'),
                'type' => \Elementor\Controls_Manager::ICONS,
            ]
        );
        $this->add_control(
            'icon_position',
            [
                'label' => __('Icon Position', 'shadepro-ts'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'after',
                'options' => [
                    'before' => __('Before', 'shadepro-ts'),
                    'after' => __('After', 'shadepro-ts'),
                ],
            ]
        );
        $this->add_responsive_control(
            'button_align',
            [
                'label' => __('Align', 'shadepro-ts'),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __('Left', 'shadepro-ts'),
                        'icon' => 'fa fa-align-left',
                    ],
                    'center' => [
                        'title' => __('top', 'shadepro-ts'),
                        'icon' => 'fa fa-align-center',
                    ],
                    'right' => [
                        'title' => __('Right', 'shadepro-ts'),
                        'icon' => 'fa fa-align-right',
                    ],
                ],
                'devices' => ['desktop', 'tablet', 'mobile'],
                'prefix_class' => 'content-align%s-',
                'toggle' => true,
            ]
        );
        $this->end_controls_section();

        /**
         * Style tab
         */
        $this->start_controls_section(
            'icon_style',
            [
                'label' => __('Icon', 'shadepro-ts'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'icon_size',
            [
                'label' => __('Icon Size', 'shadepro-ts'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .shadepro-btn .btn-icon' => 'font-size: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .shadepro-btn .btn-icon svg' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'icon_gap',
            [
                'label' => __('Icon gap', 'shadepro-ts'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .shadepro-btn .icon-before' => 'margin-right: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .shadepro-btn .icon-after ' => 'margin-left: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'icon_color',
            [
                'label' => __('Icon Color', 'shadepro-ts'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#fff',
                'selectors' => [
                    '{{WRAPPER}} .shadepro-btn .btn-icon' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .shadepro-btn .btn-icon path' => 'fill: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'play_icon_bg',
            [
                'label' => __('Background Color', 'elementor'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .shadepro-btn-wrapper .btn-icon' => 'background-color: {{VALUE}}',
                ],
                'condition' => [
                    'enable_lightbox' => 'yes',
                ],
            ]
        );
    
        $this->add_responsive_control(
            'play_icon_box_size',
            [
                'label' => __('Icon Box Size', 'elementor'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 10,
                        'max' => 500,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .shadepro-btn-wrapper .btn-icon' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}}',
                ],
                'condition' => [
                    'enable_lightbox' => 'yes',
                ],
            ]
        );
        $this->add_responsive_control(
            'icon_box_radius',
            [
                'label' => __('Border Radius', 'shadepro-ts'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'default' => [
                    'top' => '50',
                    'right' => '50',
                    'bottom' => '50',
                    'left' => '50',
                ],
                'selectors' => [
                    '{{WRAPPER}} .shadepro-btn-wrapper .btn-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'enable_lightbox' => 'boxed',
                ],
            ]
        );

        $this->end_controls_section();
        $this->start_controls_section(
            'button_style',
            [
                'label' => __('Button', 'shadepro-ts'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'heading_typography',
                'label' => __('Typography', 'shadepro-ts'),
                'scheme' => \Elementor\Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .shadepro-btn',
            ]
        );

        $this->add_control(
            'inline_btn_color',
            [
                'label' => __('Button Color', 'shadepro-ts'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#416ff4',
                'selectors' => [
                    '{{WRAPPER}} .shadepro-btn' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'button_type' => 'inline',
                ],
            ]
        );
        $this->add_control(
            'boxed_btn_color',
            [
                'label' => __('Button Color', 'shadepro-ts'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#fff',
                'selectors' => [
                    '{{WRAPPER}} .shadepro-btn' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'button_type' => 'boxed',
                ],
            ]
        );

        $this->add_control(
            'boxed_btn_background',
            [
                'label' => __('Background Color', 'shadepro-ts'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#473bf0',
                'selectors' => [
                    '{{WRAPPER}} .shadepro-btn' => 'background-color: {{VALUE}}',
                ],
                'condition' => [
                    'button_type' => 'boxed',
                ],
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'button_border',
                'label' => __('Border', 'shadepro-ts'),
                'selector' => '{{WRAPPER}} .shadepro-btn',
            ]
        );
        $this->add_responsive_control(
            'button_padding',
            [
                'label' => __('Button Padding', 'shadepro-ts'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'default' => [
                    'top' => '20',
                    'right' => '40',
                    'bottom' => '15',
                    'left' => '40',
                ],
                'selectors' => [
                    '{{WRAPPER}} .shadepro-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'button_type' => 'boxed',
                ],
            ]
        );
        $this->add_responsive_control(
            'button_radius',
            [
                'label' => __('Border Radius', 'shadepro-ts'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'default' => [
                    'top' => '8',
                    'right' => '8',
                    'bottom' => '8',
                    'left' => '8',
                ],
                'selectors' => [
                    '{{WRAPPER}} .shadepro-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'button_type' => 'boxed',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'button_shadow',
                'label' => __('Button Shadow', 'shadepro-ts'),
                'selector' => '{{WRAPPER}} .shadepro-btn',
                'fields_options' =>
                [
                    'box_shadow_type' =>
                    [
                        'default' => 'yes',
                    ],
                    'box_shadow' => [
                        'default' =>
                        [
                            'horizontal' => 0,
                            'vertical' => 0,
                            'blur' => 0,
                            'spread' => 0,
                            'color' => 'rgba(128, 128, 128, 0.16)',
                        ],
                    ],
                ],
            ]
        );
        $this->add_control(
            'btn_hover_animation',
            [
                'label' => __('Hover Animation', 'shadepro-ts'),
                'type' => \Elementor\Controls_Manager::HOVER_ANIMATION,
                // 'prefix_class' => 'elementor-animation-',
            ]
        );

        $this->add_responsive_control(
            'lightbox_content_animation',
            [
                'label' => __('Popup Animation', 'elementor'),
                'type' => \Elementor\Controls_Manager::ANIMATION,
                'frontend_available' => true,
                'condition' => [
                    'enable_lightbox' => 'yes',
                ],
            ]
        );
        $this->end_controls_section();
    }



    

    /**
     * Render oEmbed widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render()
    {
        $popular_post_key = array();
        $popular_meta_value_num = array();
        $settings = $this->get_settings_for_display();
        $target = $settings['button_url']['is_external'] ? ' target="_blank"' : '';
        $nofollow = $settings['button_url']['nofollow'] ? ' rel="nofollow"' : '';
        
        $lightbox_options = [
            'type' => 'video',
            'videoType' => 'youtube',
            'url' => \Elementor\Embed::get_embed_url( $settings['button_url']['url'] ),
            'modalOptions' => [
                'id' => 'elementor-lightbox-' . $this->get_id(),
                'entranceAnimation' => $settings['lightbox_content_animation'],
                'entranceAnimation_tablet' => $settings['lightbox_content_animation_tablet'],
                'entranceAnimation_mobile' => $settings['lightbox_content_animation_mobile'],
                'videoAspectRatio' => '169',
            ],
        ];
        $this->add_render_attribute( 'shade-btn-lightbox', [
            'data-elementor-open-lightbox' => 'yes',
            'data-elementor-lightbox' => wp_json_encode( $lightbox_options ),
        ] );
      
?>
        <div class="shadepro-btn-wrapper enable-icon-box-<?php echo esc_attr( $settings['enable_lightbox'] ) ?>">
            <?php if ('yes' != $settings['enable_lightbox']) : ?>
                <a class="shadepro-btn btn-type-<?php printf('%s %s', esc_attr($settings['button_type']), esc_attr('elementor-animation-' . $settings['btn_hover_animation'])) ?>" <?php printf('href="%s" %s %s', $settings['button_url']['url'], $nofollow, $target) ?>>
            <?php else : ?>
                <div class="shadepro-btn d-inline-flex align-items-center btn-type-<?php printf('%s %s', esc_attr($settings['button_type']), esc_attr('elementor-animation-' . $settings['btn_hover_animation'])) ?>" <?php echo $this->get_render_attribute_string( 'shade-btn-lightbox' ); ?>>
            <?php endif; ?>

                    <?php if ('before' == $settings['icon_position'] && !empty($settings['icon']['value'])) : ?>
                        <span class="icon-before  btn-icon"><?php \Elementor\Icons_Manager::render_icon($settings['icon'], ['aria-hidden' => 'true']) ?></span>
                    <?php endif; ?>

                    <?php echo $settings['button_label'] ?>

                    <?php if ('after' == $settings['icon_position'] && !empty($settings['icon']['value'])) : ?>
                        <span class="icon-after btn-icon"><?php \Elementor\Icons_Manager::render_icon($settings['icon'], ['aria-hidden' => 'true']) ?></span>
                    <?php endif; ?>
                    <?php if ('yes' != $settings['enable_lightbox']) : ?>
                </a>
            <?php else : ?>
            </div>
            <?php endif; ?>
    </div>
<?php
    }
}
