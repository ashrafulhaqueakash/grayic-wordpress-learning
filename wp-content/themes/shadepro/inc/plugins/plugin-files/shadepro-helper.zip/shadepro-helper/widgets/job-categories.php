<?php
if (!defined('ABSPATH')) {
    exit;
}
// Exit if accessed directly

/**
 * Elementor Hello World
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class ShadeProJobCat extends \Elementor\Widget_Base
{

    /**
     * Retrieve the widget name.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name()
    {
        return 'shadepro-job-categories';
    }


    /**
     * Retrieve the widget title.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title()
    {
        return __('ShadePro Job Categories', 'shadpro-ts');
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon()
    {
        return 'eicon-image';
    }

    /**
     * Retrieve the list of categories the widget belongs to.
     *
     * Used to determine where to display the widget in the editor.
     *
     * Note that currently Elementor supports only one category.
     * When multiple categories passed, Elementor uses the first one.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories()
    {
        return ['shadpro-addons'];
    }

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function _register_controls()
    {
        $this->start_controls_section(
            'section_layout',
            [
                'label' => __('General', 'shadepro-ts'),
            ]
        );

        $this->add_control(
            'category_count',
            [
                'label' => __('Category Limit', 'shadepro-ts'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 6,
            ]
        );


        $this->add_responsive_control(
            'bottom_gap',
            [
                'label' => __('Bottom Gap', 'shadepro-ts'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'devices' => ['desktop', 'tablet', 'mobile'],
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}}  .shade-job-cat' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();
        $this->start_controls_section(
            'section_style',
            [
                'label' => __('Title', 'shadepro-ts'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'label' => __('Title Typography', 'shadepro-ts'),
                'name' => 'title_typo',
                'selector' => '{{WRAPPER}} .shade-job-cat .job-cat-title',
            ]
        );
        $this->add_control(
            'title_color',
            [
                'label' => __('Title Color', 'shadepro-ts'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .shade-job-cat .job-cat-title' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'title_gap',
            [
                'label' => __('Title gap', 'shadepro-ts'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 400,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}}  .shade-job-cat .job-count' => 'margin-top:{{SIZE}}{{UNIT}};',


                ],
            ]
        );
        $this->end_controls_section();
        $this->start_controls_section(
            'section_subtitle',
            [
                'label' => __('Subtitle', 'shadepro-ts'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'label' => __('Title Typography', 'shadepro-ts'),
                'name' => 'subtitle_typo',
                'selector' => '{{WRAPPER}} .shade-job-cat .job-count',
            ]
        );
        $this->add_control(
            'subtitle_color',
            [
                'label' => __('Color', 'shadepro-ts'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .shade-job-cat .job-count' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'subtitle_gap',
            [
                'label' => __('Title gap', 'shadepro-ts'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 400,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}}  .shade-job-cat ' => 'margin-bottom:{{SIZE}}{{UNIT}};',


                ],
            ]
        );
        $this->end_controls_section();
        $this->start_controls_section(
            'section_box_style',
            [
                'label' => __('Box', 'shadepro-ts'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_responsive_control(
            'box_padding',
            [
                'label' => __('Padding', 'shadepro-ts'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .shade-job-cat ' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'box_radikus',
            [
                'label' => __('Border Radius', 'shadepro-ts'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .shade-job-cat ' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();
    }
    /**
     * Render the widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function render()
    {

        $settings = $this->get_settings();

        $taxonomy     = 'job-category';
        $orderby      = 'date';
        $show_count   = 1;
        $pad_counts   = 0;
        $hierarchical = 0;
        $title        = '';
        $empty        = 0;

        $args = array(
            'taxonomy'     => $taxonomy,
            'order'        => 'DESC',
            'orderby'      => 'date',
            'show_count'   => $show_count,
            'pad_counts'   => $pad_counts,
            'hierarchical' => $hierarchical,
            'title_li'     => $title,
            'hide_empty'   => $empty,
            'number'       => $settings['category_count'] + 1
        );
        $all_categories = get_categories($args);
?>
        <div class="product-categories-wrap row justify-content-center">
            <?php
            foreach ($all_categories as $cat) {
                $category_id = $cat->term_id;
                $product_count_label = _nx('Job', 'Jobs', $cat->category_count, 'Job', 'shadepro-ts');
                $list = '';
            ?>

                <div class="col-lg-4 col-md-6 shade-job-cat-wrap">
                    <a class="shade-job-cat" href="<?php echo get_term_link($cat->slug, 'job-category') ?>">
                        <h4 class="job-cat-title"><?php echo $cat->name ?></h4>
                        <span class="job-count"> <?php echo $cat->category_count ?> <?php echo $product_count_label ?></span>
                        <div class="job-cat-icon"><i class="fas fa-arrow-right"></i></div>
                    </a>
                </div>
            <?php


            } ?>

        </div>
<?php
    }
}
