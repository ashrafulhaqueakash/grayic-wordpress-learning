<?php
if (!defined('ABSPATH')) {
    exit;
}




function shadepro_cpt_taxonomy_slug_and_name($taxonomy_name, $option_tag = false)
{
    $taxonomyies = get_terms($taxonomy_name);

    if(true == $option_tag){
        $cpt_terms = '';
        foreach ($taxonomyies as $category) {
            $cpt_terms .= '<option value="'.esc_attr( $category->slug).'">'.  $category->name .'</option>';
            // var_dump($category->slug);
        }
        return $cpt_terms;
    }

    $cpt_terms = [];
    foreach ($taxonomyies as $category) {
        $cpt_terms[$category->slug] = $category->name;
        // var_dump($category->slug);
    }

    return $cpt_terms;
}

function shadepro_cpt_taxonomy_id_and_name($taxonomy_name)
{

    $taxonomyies = get_terms($taxonomy_name);

    $cpt_terms = [];
    foreach ($taxonomyies as $category) {
        $cpt_terms[$category->term_id] = $category->name;
    }

    return $cpt_terms;
}







function shadepro_cpt_author_slug_and_id($post_type)
{
    $the_query = new WP_Query(array(
        'posts_per_page' => -1,
        'post_type' => $post_type,

    ));
    $author_meta = [];

    while ($the_query->have_posts()) : $the_query->the_post();
        $author_meta[get_the_author_meta('ID')] = get_the_author_meta('display_name');
    endwhile;
    wp_reset_postdata();

    return array_unique($author_meta);
}



function shadepro_cpt_slug_and_id($post_type)
{
    $the_query = new WP_Query(array(
        'posts_per_page' => -1,
        'post_type' => $post_type,

    ));
    $cpt_posts = [];

    while ($the_query->have_posts()) : $the_query->the_post();
        $cpt_posts[get_the_ID()] = get_the_title();
    endwhile;


    wp_reset_postdata();
    return $cpt_posts;
}


function shadepro_get_meta_field_keys($post_type, $field_name, $fild_type = "choices")
{
    $the_query = new WP_Query(array(
        'posts_per_page' => 1,
        'post_type' => $post_type,

    ));
    $field_object = [];

    while ($the_query->have_posts()) : $the_query->the_post();
        $field_object = get_field_object($field_name)[$fild_type];
    endwhile;

    return $field_object;
    wp_reset_postdata();
}






/**
 * Create Custom Query Vars
 * https://codex.wordpress.org/Function_Reference/get_query_var#Custom_Query_Vars
 */
function shadepro_job_query_vars_filter($vars)
{
    // add custom query vars that will be public
    // https://codex.wordpress.org/WordPress_Query_Vars
    $vars[] .= 'search_key';
    $vars[] .= 'job_location';
    $vars[] .= 'job_type';
    return $vars;
}
add_filter('query_vars', 'shadepro_job_query_vars_filter');



/**
 * Override Movie Archive Query
 * https://codex.wordpress.org/Plugin_API/Action_Reference/pre_get_posts
 */
function shadepro_job_search_query($query)
{
    // only run this query if we're on the job archive page and not on the admin side
    if ($query->is_archive('job') && $query->is_main_query() && !is_admin()) {

        // get query vars from url.
        // https://codex.wordpress.org/Function_Reference/get_query_var#Examples
        $job_type       = get_query_var('job_type', FALSE);
        $job_location   = get_query_var('job_location', FALSE);
        $search_key     = get_query_var('search_key', FALSE);

        // used to conditionally build the tax_query
        // the tax_query is used for a custom taxonomy assigned to the post type
        // i'm using the `'relation' => 'OR'` to make the search more broad
        $tax_query_array = array('relation' => 'OR');


        // final tax_query
        $tax_query_array[] = $job_type ?  ['taxonomy' => 'job-type', 'field' => 'slug', 'terms' =>  esc_attr($job_type)]  : null;
        $tax_query_array[] = $job_location ?  ['taxonomy' => 'job-location', 'field' => 'slug', 'terms' => esc_attr($job_location)] : null;
        
        
        $query->set('tax_query', $tax_query_array);
        $query->set('s', esc_attr($search_key));
    }
}
add_action('pre_get_posts', 'shadepro_job_search_query');



function sshadepro_start_modify_html() {
    ob_start();
 }
 
 function sshadepro_end_modify_html() {
    $html = ob_get_clean();
    $html = str_replace( 'font-display:swap;', '', $html );
    echo $html;
 }
 
 add_action( 'wp_head', 'sshadepro_start_modify_html' );
 add_action( 'wp_footer', 'sshadepro_end_modify_html' );