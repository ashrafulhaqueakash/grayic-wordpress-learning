<?php
// File Security Check
if (!defined('ABSPATH')) {
	exit;
}
class ShadeProCustomPosts
{
	function __construct()
	{
		// team 
		add_action('init', array($this, 'shadepro_team'));
		add_action('init', array($this, 'shadepro_team_category'));
		add_action('init', array($this, 'shadepro_team_tags'));
		// case-study 
		// add_action('init', array($this, 'shadepro_cases_stydy'));
		// add_action('init', array($this, 'shadepro_cases_stydy_category'));
		// add_action('init', array($this, 'shadepro_cases_stydy_tags'));

		// job
		add_action('init', array($this, 'shadepro_job'));
		add_action('init', array($this, 'shadepro_job_category'));
		add_action('init', array($this, 'shadepro_job_type'));
		add_action('init', array($this, 'shadepro_job_location'));


		// services 
		add_action('init', array($this, 'shadepro_service'));
		add_action('init', array($this, 'shadepro_service_category'));
		add_action('init', array($this, 'shadepro_service_tags'));

	}
	/**
	 *
	 * ShadePro Case Study Custom Post Type
	 *
	 */
	public function shadepro_team()
	{
		$labels = array(
			'name'               => _x('Team Member', 'post type general name', 'shadepro-ts'),
			'singular_name'      => _x('Team Member', 'post type singular name', 'shadepro-ts'),
			'menu_name'          => _x('Team Member', 'admin menu', 'shadepro-ts'),
			'name_admin_bar'     => _x('Team Member', 'add new on admin bar', 'shadepro-ts'),
			'add_new'            => __('Add New Member', 'shadepro-ts'),
			'add_new_item'       => __('Add New Member', 'shadepro-ts'),
			'new_item'           => __('New Member', 'shadepro-ts'),
			'edit_item'          => __('Edit Member', 'shadepro-ts'),
			'view_item'          => __('View Member', 'shadepro-ts'),
			'all_items'          => __('All Team Members', 'shadepro-ts'),
			'search_items'       => __('Search Team Members', 'shadepro-ts'),
			'parent_item_colon'  => __('Parent :', 'shadepro-ts'),
			'not_found'          => __('No Team Members found.', 'shadepro-ts'),
			'not_found_in_trash' => __('No Team Members found in Trash.', 'shadepro-ts')
		);
		$args = array(
			'labels'             => $labels,
			'description'        => __('Description.', 'shadepro-ts'),
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'query_var'          => true,
			'menu_icon'          => 'dashicons-id',
			'rewrite'            => array('slug' => 'team', 'with_front' => true, 'pages' => true, 'feeds' => true),
			'capability_type'    => 'post',
			'has_archive'        => false,
			'hierarchical'       => true,
			'menu_position'      => null,
			'supports'           => array('title', 'editor', 'thumbnail',  'page-attributes')
		);
		register_post_type('team', $args);
	}
	public function shadepro_team_category()
	{
		$labels = array(
			'name'              => _x('Categories', 'taxonomy general name', 'shadepro-ts'),
			'singular_name'     => _x('Category', 'taxonomy singular name', 'shadepro-ts'),
			'search_items'      => __('Search Categories', 'shadepro-ts'),
			'all_items'         => __('All Categories', 'shadepro-ts'),
			'parent_item'       => __('Parent Category', 'shadepro-ts'),
			'parent_item_colon' => __('Parent Category:', 'shadepro-ts'),
			'edit_item'         => __('Edit Category', 'shadepro-ts'),
			'update_item'       => __('Update Category', 'shadepro-ts'),
			'add_new_item'      => __('Add New Category', 'shadepro-ts'),
			'new_item_name'     => __('New Category Name', 'shadepro-ts'),
			'menu_name'         => __('Category', 'shadepro-ts'),
		);
		$args = array(
			'hierarchical'      => true,
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'rewrite'           => array('slug' => 'team-category'),
		);
		register_taxonomy('team-category', array('team'), $args);
	}
	public function shadepro_team_tags()
	{
		$labels = array(
			'name'              => _x('Tags', 'taxonomy general name', 'shadepro-ts'),
			'singular_name'     => _x('Tag', 'taxonomy singular name', 'shadepro-ts'),
			'search_items'      => __('Search Tags', 'shadepro-ts'),
			'all_items'         => __('All Tags', 'shadepro-ts'),
			'parent_item'       => __('Parent Tag', 'shadepro-ts'),
			'parent_item_colon' => __('Parent Tag:', 'shadepro-ts'),
			'edit_item'         => __('Edit Tag', 'shadepro-ts'),
			'update_item'       => __('Update Tag', 'shadepro-ts'),
			'add_new_item'      => __('Add New Tag', 'shadepro-ts'),
			'new_item_name'     => __('New Tag Name', 'shadepro-ts'),
			'menu_name'         => __('Tag', 'shadepro-ts'),
		);
		$args = array(
			'hierarchical'      => false,
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'rewrite'           => array('slug' => 'team-tag'),
		);
		register_taxonomy('team-tag', array('team'), $args);
	}

	/**
	 *
	 * ShadePro Case Study Custom Post Type
	 *
	 */
	public function shadepro_job()
	{
		$labels = array(
			'name'               => _x('Job', 'post type general name', 'shadepro-ts'),
			'singular_name'      => _x('Job', 'post type singular name', 'shadepro-ts'),
			'menu_name'          => _x('Job', 'admin menu', 'shadepro-ts'),
			'name_admin_bar'     => _x('Job', 'add new on admin bar', 'shadepro-ts'),
			'add_new'            => __('Add New Job', 'shadepro-ts'),
			'add_new_item'       => __('Add New Job', 'shadepro-ts'),
			'new_item'           => __('New Job', 'shadepro-ts'),
			'edit_item'          => __('Edit Job', 'shadepro-ts'),
			'view_item'          => __('View Job', 'shadepro-ts'),
			'all_items'          => __('All Jobs', 'shadepro-ts'),
			'search_items'       => __('Search Jobs', 'shadepro-ts'),
			'parent_item_colon'  => __('Parent :', 'shadepro-ts'),
			'not_found'          => __('No Jobs found.', 'shadepro-ts'),
			'not_found_in_trash' => __('No Jobs found in Trash.', 'shadepro-ts')
		);
		$args = array(
			'labels'             => $labels,
			'description'        => __('Description.', 'shadepro-ts'),
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'query_var'          => true,
			'menu_icon'          => 'dashicons-portfolio',
			'rewrite'            => array('slug' => 'jobs', 'with_front' => true, 'pages' => true, 'feeds' => true),
			'capability_type'    => 'post',
			'has_archive'        => true,
			'hierarchical'       => true,
			'menu_position'      => null,
			'supports'           => array('elementor', 'title', 'editor', 'thumbnail', 'page-attributes')
		);
		register_post_type('job', $args);
	}
	public function shadepro_job_category()
	{
		$labels = array(
			'name'              => _x('Categories', 'taxonomy general name', 'shadepro-ts'),
			'singular_name'     => _x('Category', 'taxonomy singular name', 'shadepro-ts'),
			'search_items'      => __('Search Categories', 'shadepro-ts'),
			'all_items'         => __('All Categories', 'shadepro-ts'),
			'parent_item'       => __('Parent Category', 'shadepro-ts'),
			'parent_item_colon' => __('Parent Category:', 'shadepro-ts'),
			'edit_item'         => __('Edit Category', 'shadepro-ts'),
			'update_item'       => __('Update Category', 'shadepro-ts'),
			'add_new_item'      => __('Add New Category', 'shadepro-ts'),
			'new_item_name'     => __('New Category Name', 'shadepro-ts'),
			'menu_name'         => __('Category', 'shadepro-ts'),
		);
		$args = array(
			'hierarchical'      => true,
			'labels'            => $labels,
			'show_ui'           => true,
			'public' 			=> true,
			'show_admin_column' => true,
			'query_var'         => true,
			'publicly_queryable' => true,
			'exclude_from_search' => false,
			'rewrite'           => array('slug' => 'job-category'),
		);
		register_taxonomy('job-category', array('job'), $args);
	}




	public function shadepro_job_type()
	{
		$labels = array(
			'name'              => _x('Job Types', 'taxonomy general name', 'shadepro-ts'),
			'singular_name'     => _x('Job Type', 'taxonomy singular name', 'shadepro-ts'),
			'search_items'      => __('Search Job Types', 'shadepro-ts'),
			'all_items'         => __('All Job Types', 'shadepro-ts'),
			'parent_item'       => __('Parent Job Type', 'shadepro-ts'),
			'parent_item_colon' => __('Parent Job Type:', 'shadepro-ts'),
			'edit_item'         => __('Edit Job Type', 'shadepro-ts'),
			'update_item'       => __('Update Job Type', 'shadepro-ts'),
			'add_new_item'      => __('Add New Job Type', 'shadepro-ts'),
			'new_item_name'     => __('New Job Type Name', 'shadepro-ts'),
			'menu_name'         => __('Job Type', 'shadepro-ts'),
		);
		$args = array(
			'hierarchical'      => true,
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'rewrite'           => array('slug' => 'job-type'),
		);
		register_taxonomy('job-type', array('job'), $args);
	}


	public function shadepro_job_location()
	{
		$labels = array(
			'name'              => _x('Job Locations', 'taxonomy general name', 'shadepro-ts'),
			'singular_name'     => _x('Job Location', 'taxonomy singular name', 'shadepro-ts'),
			'search_items'      => __('Search Job Locations', 'shadepro-ts'),
			'all_items'         => __('All Job Locations', 'shadepro-ts'),
			'parent_item'       => __('Parent Job Location', 'shadepro-ts'),
			'parent_item_colon' => __('Parent Job Location:', 'shadepro-ts'),
			'edit_item'         => __('Edit Job Location', 'shadepro-ts'),
			'update_item'       => __('Update Job Location', 'shadepro-ts'),
			'add_new_item'      => __('Add New Job Location', 'shadepro-ts'),
			'new_item_name'     => __('New Job Location Name', 'shadepro-ts'),
			'menu_name'         => __('Job Location', 'shadepro-ts'),
		);
		$args = array(
			'hierarchical'      => true,
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'rewrite'           => array('slug' => 'job-location'),
		);
		register_taxonomy('job-location', array('job'), $args);
	}








	/**
	 *
	 * ShadePro Service Custom Post Type
	 *
	 */
	public function shadepro_service()
	{
		$labels = array(
			'name'               => _x('Service', 'post type general name', 'shadepro-ts'),
			'singular_name'      => _x('Service', 'post type singular name', 'shadepro-ts'),
			'menu_name'          => _x('Service', 'admin menu', 'shadepro-ts'),
			'name_admin_bar'     => _x('Service', 'add new on admin bar', 'shadepro-ts'),
			'add_new'            => __('Add New Service', 'shadepro-ts'),
			'add_new_item'       => __('Add New Service', 'shadepro-ts'),
			'new_item'           => __('New Service', 'shadepro-ts'),
			'edit_item'          => __('Edit Service', 'shadepro-ts'),
			'view_item'          => __('View Service', 'shadepro-ts'),
			'all_items'          => __('All Services', 'shadepro-ts'),
			'search_items'       => __('Search Services', 'shadepro-ts'),
			'parent_item_colon'  => __('Parent :', 'shadepro-ts'),
			'not_found'          => __('No Services found.', 'shadepro-ts'),
			'not_found_in_trash' => __('No Services found in Trash.', 'shadepro-ts')
		);
		$args = array(
			'labels'             => $labels,
			'description'        => __('Description.', 'shadepro-ts'),
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'query_var'          => true,
			'menu_icon'          => 'dashicons-megaphone',
			'rewrite'            => array('slug' => 'service', 'with_front' => true, 'pages' => true, 'feeds' => true),
			'capability_type'    => 'post',
			'has_archive'        => true,
			'hierarchical'       => true,
			'menu_position'      => null,
			'supports'           => array('elementor', 'title', 'editor', 'thumbnail', 'excerpt', 'page-attributes')
		);
		register_post_type('service', $args);
	}
	public function shadepro_service_category()
	{
		$labels = array(
			'name'              => _x('Categories', 'taxonomy general name', 'shadepro-ts'),
			'singular_name'     => _x('Category', 'taxonomy singular name', 'shadepro-ts'),
			'search_items'      => __('Search Categories', 'shadepro-ts'),
			'all_items'         => __('All Categories', 'shadepro-ts'),
			'parent_item'       => __('Parent Category', 'shadepro-ts'),
			'parent_item_colon' => __('Parent Category:', 'shadepro-ts'),
			'edit_item'         => __('Edit Category', 'shadepro-ts'),
			'update_item'       => __('Update Category', 'shadepro-ts'),
			'add_new_item'      => __('Add New Category', 'shadepro-ts'),
			'new_item_name'     => __('New Category Name', 'shadepro-ts'),
			'menu_name'         => __('Category', 'shadepro-ts'),
		);
		$args = array(
			'hierarchical'      => true,
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'rewrite'           => array('slug' => 'service-category'),
		);
		register_taxonomy('service-category', array('shadepro-service'), $args);
	}
	public function shadepro_service_tags()
	{
		$labels = array(
			'name'              => _x('Tags', 'taxonomy general name', 'shadepro-ts'),
			'singular_name'     => _x('Tag', 'taxonomy singular name', 'shadepro-ts'),
			'search_items'      => __('Search Tags', 'shadepro-ts'),
			'all_items'         => __('All Tags', 'shadepro-ts'),
			'parent_item'       => __('Parent Tag', 'shadepro-ts'),
			'parent_item_colon' => __('Parent Tag:', 'shadepro-ts'),
			'edit_item'         => __('Edit Tag', 'shadepro-ts'),
			'update_item'       => __('Update Tag', 'shadepro-ts'),
			'add_new_item'      => __('Add New Tag', 'shadepro-ts'),
			'new_item_name'     => __('New Tag Name', 'shadepro-ts'),
			'menu_name'         => __('Tag', 'shadepro-ts'),
		);
		$args = array(
			'hierarchical'      => true,
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'rewrite'           => array('slug' => 'pf-tag'),
		);
		register_taxonomy('service-tag', array('shadepro-service'), $args);
	}

















	/**
	 *
	 * ShadePro Case Study Custom Post Type
	 *
	 */
	public function shadepro_cases_stydy()
	{
		$labels = array(
			'name'               => _x('Case Study', 'post type general name', 'shadepro-ts'),
			'singular_name'      => _x('Case Study', 'post type singular name', 'shadepro-ts'),
			'menu_name'          => _x('Case Study', 'admin menu', 'shadepro-ts'),
			'name_admin_bar'     => _x('Case Study', 'add new on admin bar', 'shadepro-ts'),
			'add_new'            => __('Add New Case Study', 'shadepro-ts'),
			'add_new_item'       => __('Add New Case Study', 'shadepro-ts'),
			'new_item'           => __('New Case Study', 'shadepro-ts'),
			'edit_item'          => __('Edit Case Study', 'shadepro-ts'),
			'view_item'          => __('View Case Study', 'shadepro-ts'),
			'all_items'          => __('All Case Studies', 'shadepro-ts'),
			'search_items'       => __('Search Case Studies', 'shadepro-ts'),
			'parent_item_colon'  => __('Parent :', 'shadepro-ts'),
			'not_found'          => __('No Case Studies found.', 'shadepro-ts'),
			'not_found_in_trash' => __('No Case Studies found in Trash.', 'shadepro-ts')
		);
		$args = array(
			'labels'             => $labels,
			'description'        => __('Description.', 'shadepro-ts'),
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'query_var'          => true,
			'menu_icon'          => 'dashicons-welcome-write-blog',
			'rewrite'            => array('slug' => 'case-study', 'with_front' => true, 'pages' => true, 'feeds' => true),
			'capability_type'    => 'post',
			'has_archive'        => true,
			'hierarchical'       => true,
			'menu_position'      => null,
			'supports'           => array('elementor', 'title', 'editor', 'thumbnail', 'excerpt', 'page-attributes')
		);
		register_post_type('case-study', $args);
	}
	public function shadepro_cases_stydy_category()
	{
		$labels = array(
			'name'              => _x('Categories', 'taxonomy general name', 'shadepro-ts'),
			'singular_name'     => _x('Category', 'taxonomy singular name', 'shadepro-ts'),
			'search_items'      => __('Search Categories', 'shadepro-ts'),
			'all_items'         => __('All Categories', 'shadepro-ts'),
			'parent_item'       => __('Parent Category', 'shadepro-ts'),
			'parent_item_colon' => __('Parent Category:', 'shadepro-ts'),
			'edit_item'         => __('Edit Category', 'shadepro-ts'),
			'update_item'       => __('Update Category', 'shadepro-ts'),
			'add_new_item'      => __('Add New Category', 'shadepro-ts'),
			'new_item_name'     => __('New Category Name', 'shadepro-ts'),
			'menu_name'         => __('Category', 'shadepro-ts'),
		);
		$args = array(
			'hierarchical'      => true,
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'rewrite'           => array('slug' => 'cs-category'),
		);
		register_taxonomy('case-study-category', array('case-study'), $args);
	}
	public function shadepro_cases_stydy_tags()
	{
		$labels = array(
			'name'              => _x('Tags', 'taxonomy general name', 'shadepro-ts'),
			'singular_name'     => _x('Tag', 'taxonomy singular name', 'shadepro-ts'),
			'search_items'      => __('Search Tags', 'shadepro-ts'),
			'all_items'         => __('All Tags', 'shadepro-ts'),
			'parent_item'       => __('Parent Tag', 'shadepro-ts'),
			'parent_item_colon' => __('Parent Tag:', 'shadepro-ts'),
			'edit_item'         => __('Edit Tag', 'shadepro-ts'),
			'update_item'       => __('Update Tag', 'shadepro-ts'),
			'add_new_item'      => __('Add New Tag', 'shadepro-ts'),
			'new_item_name'     => __('New Tag Name', 'shadepro-ts'),
			'menu_name'         => __('Tag', 'shadepro-ts'),
		);
		$args = array(
			'hierarchical'      => true,
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'rewrite'           => array('slug' => 'pf-tag'),
		);
		register_taxonomy('case-study-tag', array('case-study'), $args);
	}
}
$shadeproCcases_stydyInstance = new ShadeProCustomPosts;
