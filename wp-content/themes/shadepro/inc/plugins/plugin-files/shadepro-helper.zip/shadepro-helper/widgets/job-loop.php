<?php
if (!defined('ABSPATH')) {
    exit;
}
// Exit if accessed directly

/**
 * Elementor Hello World
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class ShadeProJobLoop extends \Elementor\Widget_Base
{

    /**
     * Retrieve the widget name.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name()
    {
        return 'shadepro-job-loop';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title()
    {
        return __('ShadePro Job Loop', 'shadepro-ts');
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon()
    {
        return 'eicon-gallery-grid';
    }

    /**
     * Retrieve the list of categories the widget belongs to.
     *
     * Used to determine where to display the widget in the editor.
     *
     * Note that currently Elementor supports only one category.
     * When multiple categories passed, Elementor uses the first one.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories()
    {
        return ['shadepro-addons'];
    }

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function _register_controls()
    {
        $this->start_controls_section(
            'section_content',
            [
                'label' => __('Content', 'shadepro-ts'),
            ]
        );

        $this->add_control(
            'layout',
            [
                'label' => __('Layout Mode', 'shadepro-ts'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'column' => __('Box', 'shadepro-ts'),
                    'list' => __('List', 'shadepro-ts'),
                ],
                'default' => 'column'
            ]
        );

        $this->add_control(
            'posts_per_page',
            [
                'label' => __('Jobs Count', 'shadepro-ts'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 5,
            ]
        );

        $this->end_controls_section();


        $this->start_controls_section(
            'icon_style',
            [
                'label' => __('Icon', 'shadepro-ts'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_responsive_control(
            'icon_size',
            [
                'label' => __('Icon Size', 'shadepro-ts'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 5500,
                    ],
                ],
                'devices' => ['desktop', 'tablet', 'mobile'],
                'selectors' => [
                    '{{WRAPPER}}  .shadepro-job-list-item i' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'icon_postion',
            [
                'label' => __('Icon Postion', 'shadepro-ts'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                    ],
                ],
                'devices' => ['desktop', 'tablet', 'mobile'],
                'selectors' => [
                    '{{WRAPPER}}  .shadepro-job-list-item i' => 'right: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();


        $this->start_controls_section(
            'content_style',
            [
                'label' => __('Content', 'shadepro-ts'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_responsive_control(
            'job_type_gap',
            [
                'label' => __('Job Type Gap', 'shadepro-ts'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'devices' => ['desktop', 'tablet', 'mobile'],
                'selectors' => [
                    '{{WRAPPER}}  .job-type' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );


        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'jobtype_typo',
                'label' => __('Job Type Typography', 'shadepro-ts'),
                'selector' => '{{WRAPPER}} .job-type',
            ]
        );
        $this->add_control(
            'jobtype_color',
            [
                'label' => __('Job Type Color', 'shadepro-ts'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .job-type' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'job_type_br',
            [
                'type' => \Elementor\Controls_Manager::DIVIDER,
            ]
        );
        $this->add_responsive_control(
            'job_title_gap',
            [
                'label' => __('Job Title Gap', 'shadepro-ts'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'devices' => ['desktop', 'tablet', 'mobile'],
                'selectors' => [
                    '{{WRAPPER}} .job-title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );


        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'heading_typography',
                'label' => __('Title Typography', 'shadepro-ts'),
                'selector' => '{{WRAPPER}} .job-title',
            ]
        );
        $this->add_control(
            'title_color',
            [
                'label' => __('Title Color', 'shadepro-ts'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}}  .job-title' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'title_br',
            [
                'type' => \Elementor\Controls_Manager::DIVIDER,
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'address_typ',
                'label' => __('Location Typography', 'shadepro-ts'),
                'selector' => '{{WRAPPER}} .job-location',
            ]
        );


        $this->add_control(
            'description_color',
            [
                'label' => __('Description Color', 'shadepro-ts'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .job-location' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_section();
        $this->start_controls_section(
            'section_box_style',
            [
                'label' => __('Box', 'shadepro-ts'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'border',
                'label' => __('Border', 'shadepro-ts'),
                'selector' => '{{WRAPPER}} .shade-job-item,{{WRAPPER}} .shadepro-job-list-item',
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'box_shadow',
                'label' => __('Box Hover Shadow', 'shadepro-ts'),
                'selector' => '{{WRAPPER}} .shade-job-item:hover, {{WRAPPER}} .shadepro-job-list-item',
            ]
        );

        $this->add_responsive_control(
            'box_border_radius',
            [
                'label' => __('Box Border Radius', 'shadepro-ts'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .shade-job-item,{{WRAPPER}} .shadepro-job-list-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
            ]
        );

        $this->add_responsive_control(
            'box_padding',
            [
                'label' => __('Box Padding', 'shadepro-ts'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .shade-job-item,{{WRAPPER}} .shadepro-job-list-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
            ]
        );
        $this->end_controls_section();
    }

    /**
     * Render the widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function render()
    {
        $settings = $this->get_settings();

        $the_query = new WP_Query(array(
            'posts_per_page' => $settings['posts_per_page'],
            'post_type' => 'job',
            'paged' => get_query_var('paged') ? get_query_var('paged') : 1
        ));
        if ('column' == $settings['layout']) {
            $wrapper_class = "shade-job-carousel owl-carousel";
        } else {
            $wrapper_class = "job-list-wrap";
        }
?>
        <div class="<?php echo esc_attr($wrapper_class); ?>">
            <?php while ($the_query->have_posts()) : $the_query->the_post();
                $idd = get_the_ID();
                $job_type = get_the_terms($idd, 'job-type');
                $job_type = join(', ', wp_list_pluck($job_type, 'name'));

                $job_location = get_the_terms($idd, 'job-location');
                $job_location = join(', ', wp_list_pluck($job_location, 'name'));

                $company_logo = get_post_meta($idd, 'company_logo', true);
                $company_logo = wp_get_attachment_image($company_logo, 'full');


            ?>
            <?php if('column' == $settings['layout']): ?>
                <div class="shade-job-item-wrap">
                    <a href="<?php echo esc_url(get_the_permalink()) ?>" class="shade-job-item">
                        <div class="job-content">
                            <span class="job-type"><?php echo esc_html($job_type) ?></span>
                            <h4 class="job-title"><?php echo get_the_title() ?></h4>
                            <span class="job-location"><?php echo esc_html($job_location) ?></span>
                        </div>
                        <div class="job-company-logo">
                            <?php echo $company_logo; ?>
                            <span class="job-company-name"><?php echo esc_html(get_post_meta($idd, 'company_name', true)); ?></span>
                        </div>
                    </a>
                </div>
             <?php else: ?>

                    <a href="<?php echo get_the_permalink() ?>" class="job-details-link shadepro-job-list-item d-block">
                        <?php the_title('<h4 class="job-title">', '</h4>') ?>
                        <div class="shadepro-job-meta">
                            <?php if (!empty($job_type)) : ?>
                                <span class="job-address job-type"> <?php echo esc_html($job_type); echo $job_location ?   esc_html(', '): ''; ?></span>
                            <?php endif; ?>
                            <?php if (!empty($job_location)) : ?>
                                <span class="job-address job-location"> <?php echo esc_html( $job_location) ?></span>
                            <?php endif; ?>
                        </div>
                        <i class="fa fa-arrow-right"></i>
                    </a>

            <?php endif; ?>

    <?php
            endwhile;
            echo '</div>';



            wp_reset_postdata();
        }
    }
