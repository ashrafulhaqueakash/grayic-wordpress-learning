<?php


/**
 * Elementor oEmbed Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class ShadeProFeatureBox extends \Elementor\Widget_Base
{

	/**
	 * Get widget name.
	 *
	 * Retrieve oEmbed widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name()
	{
		return 'shadepro-feature-box';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve oEmbed widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title()
	{
		return __('ShadePro Icon Box', 'shadepro-ts');
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve oEmbed widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon()
	{
		return 'eicon-icon-box';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the oEmbed widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories()
	{
		return ['shadepro-addons'];
	}

	/**
	 * Register oEmbed widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls()
	{

		/**
		 * Content tab
		 */
		$this->start_controls_section(
			'content_section',
			[
				'label' => __('Content', 'shadepro-ts'),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'icon_type',
			[
				'label' => __('Icon type', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'icon',
				'options' => [
					'text'  => __('Text', 'shadepro-ts'),
					'icon' => __('Icon', 'shadepro-ts'),
					'image' => __('Image', 'shadepro-ts'),
				],
			]
		);
		$this->add_control(
			'icon',
			[
				'label' => __('Icon', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-star',
					'library' => 'solid',
				],
				'condition' => ['icon_type' => 'icon']
			]
		);
		$this->add_control(
			'box_number',
			[
				'label' => __('Box Number', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'condition' => ['icon_type' => 'text']
			]
		);
		$this->add_control(
			'image',
			[
				'label' => __('Choose Image', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
				'condition' => ['icon_type' => 'image']
			]
		);

		$this->add_control(
			'title',
			[
				'label' => __('Title', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'default' => __('Easy Intragition', 'shadepro-ts')
			]
		);

		$this->add_control(
			'description',
			[
				'label' => __('Description', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => __('Lorem ipsum dolor sit amet, consetetur sadipscing elitr love it', 'shadepro-ts')
			]
		);
		$this->add_control(
			'enable_button',
			[
				'label' => __('SHow Button', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __('Show', 'shadepro-ts'),
				'label_off' => __('Hide', 'shadepro-ts'),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);
		$this->add_control(
			'btn_icon',
			[
				'label' => __('Button Icon', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-arrow-right',
					'library' => 'solid',
				],
				'condition' => ['enable_button' => 'yes']
			]
		);
		$this->add_control(
			'button_text',
			[
				'label' => __('Button Text', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'default' => __('Learn more', 'shadepro-ts'),
				'condition' => ['enable_button' => 'yes']
			]
		);
		$this->add_control(
			'button_url',
			[
				'label' => __('URL', 'shadepro-ts'),
				'type' =>  \Elementor\Controls_Manager::URL,
				'condition' => ['enable_button' => 'yes']
			]
		);



		$this->add_control(
			'content_align',
			[
				'label' => __('Align', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __('Left', 'shadepro-ts'),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __('top', 'shadepro-ts'),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __('Right', 'shadepro-ts'),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'center',
				'toggle' => true,
			]
		);

		$this->end_controls_section();


		/**
		 * Style tab
		 */

		$this->start_controls_section(
			'icon_style',
			[
				'label' => __('Icon', 'shadepro-ts'),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'enable_icon_box',
			[
				'label' => __('Enable Icon Box', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __('Show', 'shadepro-ts'),
				'label_off' => __('Hide', 'shadepro-ts'),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		$this->start_controls_tabs(
			'icon_hover_tabs'
		);

		$this->start_controls_tab(
			'icon_normal_tab',
			[
				'label' => __('Normal', 'shadepro-ts'),
			]
		);

		$this->add_control(
			'icon_color',
			[
				'label' => __('Icon Color', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .shadepro-feature-icon i' => 'color: {{VALUE}}',
					'{{WRAPPER}} .shadepro-feature-icon svg' => 'color: {{VALUE}}',
					'{{WRAPPER}} .shadepro-feature-icon svg path' => 'fill: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'icon_background',
			[
				'label' => __('Icon Background', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#416ff4',
				'selectors' => [
					'{{WRAPPER}} .icon-background-yes .shadepro-feature-icon' => 'background-color: {{VALUE}}',
				],
				'condition' => ['enable_icon_box' => 'yes']
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'style_hover_tab',
			[
				'label' => __('Hover', 'shadepro-ts'),
			]
		);
		$this->add_control(
			'icon_hover_color',
			[
				'label' => __('Icon Color', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}:hover .shadepro-feature-icon i' => 'color: {{VALUE}}',
					'{{WRAPPER}}:hover .shadepro-feature-icon svg' => 'color: {{VALUE}}',
					'{{WRAPPER}}:hover .shadepro-feature-icon svg path' => 'fill: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'icon_hover_background',
			[
				'label' => __('Icon Background', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}:hover .icon-background-yes .shadepro-feature-icon' => 'background-color: {{VALUE}}',
				],
				'condition' => ['enable_icon_box' => 'yes']
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->add_control(
			'icon_br',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'icon_text_typo',
				'label' => __('Icon Text Typography', 'shadepro-ts'),
				'scheme' => \Elementor\Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .shadepro-feature-box-item .shadepro-feature-icon',
				'condition' => ['icon_type' => 'text']
			]
		);
		$this->add_responsive_control(
			'icon_size',
			[
				'label' => __('Icon Size', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => ['px', '%'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices' => ['desktop', 'tablet', 'mobile'],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}}  .shadepro-feature-box-item .shadepro-feature-icon.icon-type-icon i' => 'font-size: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}}  .shadepro-feature-box-item .shadepro-feature-icon.icon-type-icon svg' => 'width: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}}  .shadepro-feature-box-item .shadepro-feature-icon.icon-type-image img' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'icon_type' => 'icon',
				]
			]
		);
		
		
		$this->add_responsive_control(
			'image_width',
			[
				'label' => __('Image Width', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => ['px', '%'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices' => ['desktop', 'tablet', 'mobile'],
				'selectors' => [
					'{{WRAPPER}}  .shadepro-feature-box-item .shadepro-feature-icon.icon-type-image img' => 'width: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}}  .shadepro-feature-box-item .shadepro-feature-icon.icon-type-image' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'icon_type' => 'image'
				]
			]
		);
		$this->add_responsive_control(
			'image_height',
			[
				'label' => __('Image Height', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => ['px', '%'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices' => ['desktop', 'tablet', 'mobile'],
				'selectors' => [
					'{{WRAPPER}}  .shadepro-feature-box-item .shadepro-feature-icon.icon-type-image img' => 'height: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}}  .shadepro-feature-box-item .shadepro-feature-icon.icon-type-image' => 'height: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'icon_type' => 'image'
				]
			]
		);


		$this->add_responsive_control(
			'icon_box_size',
			[
				'label' => __('Icon Box Size', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => ['px', '%'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices' => ['desktop', 'tablet', 'mobile'],
				'desktop_default' => [
					'size' => 70,
					'unit' => 'px',
				],
				'tablet_default' => [
					'size' => 70,
					'unit' => 'px',
				],
				'mobile_default' => [
					'size' => 70,
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}}  .shadepro-feature-box-item .icon-background-yes .shadepro-feature-icon' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				],
				'condition' => ['enable_icon_box' => 'yes']
			]
		);
		$this->add_responsive_control(
			'icon_border_radius',
			[
				'label' => __('Icon Border Radius', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'default'	=>	[
					'top' => '10',
					'right' => '10',
					'bottom' => '10',
					'left' => '10'
				],
				'selectors' => [
					'{{WRAPPER}} .shadepro-feature-box-item .icon-background-yes .shadepro-feature-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => ['enable_icon_box' => 'yes']
			]
		);
		$this->add_responsive_control(
			'space_between_icon',
			[
				'label' => __('Icon Gap', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices' => ['desktop', 'tablet', 'mobile'],
				'desktop_default' => [
					'size' => 30,
					'unit' => 'px',
				],
				'tablet_default' => [
					'size' => 20,
					'unit' => 'px',
				],
				'mobile_default' => [
					'size' => 10,
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}}  .shadepro-feature-icon-wrap' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'icon_shadow',
				'label' => __('Icon Shadow', 'shadepro-ts'),
				'selector' => '{{WRAPPER}} .shadepro-feature-icon',
			]
		);
		$this->end_controls_section();
		$this->start_controls_section(
			'content_style',
			[
				'label' => __('Content', 'shadepro-ts'),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		/* $this->add_control(
			'box_number_color',
			[
				'label' => __('Box Number Color', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}:hover .shadepro-feature-box-number' => 'color: {{VALUE}}',
				],
				'condition' => ['enable_box_number' => 'yes']
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'box_number_typo',
				'label' => __('Box Number Typography', 'shadepro-ts'),
				'scheme' => \Elementor\Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .shadepro-feature-box-number',
				'condition' => ['enable_box_number' => 'yes']
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'box_number_border',
				'label' => __('BOx Number Border', 'shadepro-ts'),
				'selector' => '{{WRAPPER}} .shadepro-feature-box-number span',
				'condition' => ['enable_box_number' => 'yes']
			]
		);
		$this->add_responsive_control(
			'box_number_gap',
			[
				'label' => __('Box Number Gap', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices' => ['desktop', 'tablet', 'mobile'],
				'desktop_default' => [
					'size' => 30,
					'unit' => 'px',
				],
				'tablet_default' => [
					'size' => 20,
					'unit' => 'px',
				],
				'mobile_default' => [
					'size' => 10,
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} .shadepro-feature-box-number' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
				'condition' => ['enable_box_number' => 'yes']

			]
		); */

		$this->add_control(
			'title_br',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
				'condition' => ['enable_box_number' => 'yes']
			]
		);
		$this->add_responsive_control(
			'title_gap',
			[
				'label' => __('Title Gap', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices' => ['desktop', 'tablet', 'mobile'],
				'desktop_default' => [
					'size' => 30,
					'unit' => 'px',
				],
				'tablet_default' => [
					'size' => 20,
					'unit' => 'px',
				],
				'mobile_default' => [
					'size' => 10,
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} .shadepro-feature-title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'title_color',
			[
				'label' => __('Title Color', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '##161C2D',
				'selectors' => [
					'{{WRAPPER}} .shadepro-feature-title' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'heading_typography',
				'label' => __('Title Typography', 'shadepro-ts'),
				'scheme' => \Elementor\Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .shadepro-feature-title',
			]
		);

		$this->add_control(
			'desc_br',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);


		$this->add_responsive_control(
			'desc_gap',
			[
				'label' => __('Description Gap', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices' => ['desktop', 'tablet', 'mobile'],
				'desktop_default' => [
					'size' => 30,
					'unit' => 'px',
				],
				'tablet_default' => [
					'size' => 20,
					'unit' => 'px',
				],
				'mobile_default' => [
					'size' => 10,
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} .shadepro-feature-content' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
				'condition' => ['enable_button' => 'yes']

			]
		);

		$this->add_control(
			'desscription_color',
			[
				'label' => __('Description Color', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#7A7A7A',
				'selectors' => [
					'{{WRAPPER}} .shadepro-feature-content' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'description_typography',
				'label' => __('Description Typography', 'shadepro-ts'),
				'scheme' => \Elementor\Scheme_Typography::TYPOGRAPHY_3,
				'selector' => '{{WRAPPER}} .shadepro-feature-content',
			]
		);

		$this->end_controls_section();
		$this->start_controls_section(
			'button_style',
			[
				'label' => __('Button', 'shadepro-ts'),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
			'space_between_btn',
			[
				'label' => __('Button Icon Gap', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices' => ['desktop', 'tablet', 'mobile'],
				'desktop_default' => [
					'size' => 20,
					'unit' => 'px',
				],
				'tablet_default' => [
					'size' => 20,
					'unit' => 'px',
				],
				'mobile_default' => [
					'size' => 10,
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}}  .shadepro-feature-btn i, {{WRAPPER}}  .shadepro-feature-btn svg' => 'margin-left: {{SIZE}}{{UNIT}};',
				],
				'condition' => ['enable_button' => 'yes']
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'button_typography',
				'label' => __('Button Typography', 'shadepro-ts'),
				'selector' => '{{WRAPPER}} .shadepro-feature-box-item .shadepro-feature-btn',
				'condition' => ['enable_button' => 'yes']
			]
		);

		$this->add_control(
			'button_color',
			[
				'label' => __('Button Color', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .shadepro-feature-box-item .shadepro-feature-btn' => 'color: {{VALUE}}',
				],
				'condition' => ['enable_button' => 'yes']
			]
		);
		$this->add_control(
			'button_background',
			[
				'label' => __('Button Background Color', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .shadepro-feature-box-item .shadepro-feature-btn' => 'background-color: {{VALUE}}',
				],
				'condition' => ['enable_button' => 'yes']
			]
		);

		$this->add_responsive_control(
			'button_padding',
			[
				'label' => __('Button Padding', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'default'	=>	[
					'top' => '20',
					'right' => '45',
					'bottom' => '20',
					'left' => '45'
				],
				'selectors' => [
					'{{WRAPPER}} .shadepro-feature-box-item .shadepro-feature-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => ['enable_button' => 'yes']
			]
		);

		$this->add_responsive_control(
			'button_border_radius',
			[
				'label' => __('Button Border Radius', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'default'	=>	[
					'top' => '10',
					'right' => '10',
					'bottom' => '10',
					'left' => '10'
				],
				'selectors' => [
					'{{WRAPPER}} .shadepro-feature-box-item .shadepro-feature-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => ['enable_button' => 'yes']
			]
		);
		$this->end_controls_section();
		$this->start_controls_section(
			'box_style',
			[
				'label' => __('Box', 'shadepro-ts'),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'box_background',
			[
				'label' => __('Box Background Color', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .shadepro-feature-box-item' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control(
			'box_border_radius',
			[
				'label' => __('Box Border Radius', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'default'	=>	[
					'top' => '10',
					'right' => '10',
					'bottom' => '10',
					'left' => '10'
				],
				'selectors' => [
					'{{WRAPPER}} .shadepro-feature-box-item ' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'content_padding',
			[
				'label' => __('Content Padding', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors' => [
					'{{WRAPPER}} .shadepro-feature-content-wrap' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);


		$this->add_responsive_control(
			'box_padding',
			[
				'label' => __('Box Padding', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'default'	=>	[
					'top' => 'inherit',
					'right' => 'inherit',
					'bottom' => 'inherit',
					'left' => 'inherit'
				],
				'selectors' => [
					'{{WRAPPER}} .shadepro-feature-box-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);


		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'box_shadow',
				'label' => __('Box Shadow', 'shadepro-ts'),
				'selector' => '{{WRAPPER}} .shadepro-feature-box-item',
				'fields_options' =>
				[
					'box_shadow_type' =>
					[
						'default' => 'yes'
					],
					'box_shadow' => [
						'default' =>
						[
							'horizontal' => 1,
							'vertical' => 12,
							'blur' => 18,
							'spread' => 0,
							'color' => 'rgba(128, 128, 128, 0.16)'
						]
					]
				]
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'box_hover_shadow',
				'label' => __('Box Hover Shadow', 'shadepro-ts'),
				'selector' => '{{WRAPPER}} .shadepro-feature-box-item:HOVER',
			]
		);


		$this->end_controls_section();
	}

	/**
	 * Render oEmbed widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render()
	{
		$settings = $this->get_settings_for_display();
		$target = isset($settings['button_url']['is_external']) ? ' target="_blank"' : '';
		$nofollow = isset($settings['button_url']['nofollow']) ? ' rel="nofollow"' : '';
		$this->add_inline_editing_attributes('title', 'none');
		$this->add_inline_editing_attributes('description', 'basic');
?>
		<div class="shadepro-feature-box-item shadepro-feature-icon-<?php echo $settings['content_align'] ?>">

			<div class="shadepro-feature-icon-wrap icon-background-<?php echo ($settings['enable_icon_box']) ? esc_attr('yes') : esc_html('no') ?>">
				<span class="shadepro-feature-icon icon-type-<?php echo $settings['icon_type'] ?>">
					<?php
					if ('text' == $settings['icon_type']) {
						echo esc_html($settings['box_number']);
					} elseif ('image' == $settings['icon_type']) {
						echo \Elementor\Group_Control_Image_Size::get_attachment_image_html($settings);
					} else {
						\Elementor\Icons_Manager::render_icon($settings["icon"], ['aria-hidden' => 'true']);
					}
					?>


				</span>
			</div>
			<div class="shadepro-feature-content-wrap">
				<div class="shadepro-feature-content">
					<h4 class="shadepro-feature-title"><?php echo $settings['title'] ?></h4>
					<p><?php echo $settings['description'] ?></p>
				</div>
				<?php if ('yes' == $settings['enable_button']) { ?>
					<a <?php printf('href="%s" %s %s', $settings['button_url']['url'], $nofollow, $target) ?> class="shadepro-feature-btn shadepro-btn btn-type-boxed"><?php echo $settings['button_text'];
																																										\Elementor\Icons_Manager::render_icon($settings["btn_icon"], ['aria-hidden' => 'true']); ?></a>
				<?php } ?>
			</div>
		</div>
<?php
	}
}
