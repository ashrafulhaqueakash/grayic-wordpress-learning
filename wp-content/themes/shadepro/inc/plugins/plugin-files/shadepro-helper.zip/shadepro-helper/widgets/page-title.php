<?php

/**
 * Elementor oEmbed Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class ShadeProPageTitle extends \Elementor\Widget_Base
{

    /**
     * Get widget name.
     *
     * Retrieve oEmbed widget name.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name()
    {
        return 'shadepro-heading';
    }

    /**
     * Get widget title.
     *
     * Retrieve oEmbed widget title.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title()
    {
        return __('ShadePro Page Title', 'shadepro-ts');
    }

    /**
     * Get widget icon.
     *
     * Retrieve oEmbed widget icon.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon()
    {
        return 'eicon-heading';
    }

    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the oEmbed widget belongs to.
     *
     * @since 1.0.0
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories()
    {
        return ['shadepro-addons'];
    }

    /**
     * Register oEmbed widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function _register_controls()
    {

        /**
         * Content tab
         */
        $this->start_controls_section(
            'Content',
            [
                'label' => __('Content', 'shadepro-ts'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'custom_title',
            [
                'label' => __('Custom Title', 'shadepro-ts'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'shadepro-ts'),
                'label_off' => __('No', 'shadepro-ts'),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );
        $this->add_control(
            'heading_label',
            [
                'label' => __('Heading text', 'shadepro-ts'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'condition' => [ 'custom_title' => 'yes' ]
            ]
        );
        $this->add_control(
            'heading_tags',
            [
                'label' => __('Title Tag', 'shadepro-ts'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'h3',
                'options' => [
                    'h1' => __('h1', 'shadepro-ts'),
                    'h2' => __('h2', 'shadepro-ts'),
                    'h3' => __('h3', 'shadepro-ts'),
                    'h4' => __('h4', 'shadepro-ts'),
                    'h5' => __('h5', 'shadepro-ts'),
                    'h6' => __('h6', 'shadepro-ts'),
                    'span' => __('span', 'shadepro-ts'),
                    'p' => __('p', 'shadepro-ts'),
                    'strong' => __('strong', 'shadepro-ts'),
                ],
            ]
        );
        $this->add_control(
            'heading_url',
            [
                'label' => __('Heading URL', 'shadepro-ts'),
                'type' => \Elementor\Controls_Manager::URL,
            ]
        );

        $this->add_control(
            'icon',
            [
                'label' => __('Icon', 'shadepro-ts'),
                'type' => \Elementor\Controls_Manager::ICONS,
            ]
        );
        $this->add_control(
            'icon_position',
            [
                'label' => __('Icon Position', 'shadepro-ts'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'after',
                'options' => [
                    'before' => __('Before', 'shadepro-ts'),
                    'after' => __('After', 'shadepro-ts'),
                ],
            ]
        );
        $this->add_responsive_control(
            'heading_align',
            [
                'label' => __('Align', 'shadepro-ts'),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __('Left', 'shadepro-ts'),
                        'icon' => 'fa fa-align-left',
                    ],
                    'center' => [
                        'title' => __('top', 'shadepro-ts'),
                        'icon' => 'fa fa-align-center',
                    ],
                    'right' => [
                        'title' => __('Right', 'shadepro-ts'),
                        'icon' => 'fa fa-align-right',
                    ],
                ],
                'devices' => ['desktop', 'tablet', 'mobile'],
                'prefix_class' => 'content-align%s-',
                'toggle' => true,
            ]
        );
        $this->end_controls_section();

        /**
         * Style tab
         */

        $this->start_controls_section(
            'title_typography',
            [
                'label' => __('title', 'shadepro-ts'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'icon_size',
            [
                'label' => __('Icon Size', 'shadepro-ts'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                        'step' => 5,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .shadepro-heading .heading-icon' => 'font-size: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .shadepro-heading .heading-icon svg' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'icon_gap',
            [
                'label' => __('Icon gap', 'shadepro-ts'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .shadepro-heading .icon-before' => 'margin-right: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .shadepro-heading .icon-after ' => 'margin-left: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'icon_color',
            [
                'label' => __('Icon Color', 'shadepro-ts'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#fff',
                'selectors' => [
                    '{{WRAPPER}} .shadepro-heading .heading-icon' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .shadepro-heading .heading-icon path' => 'fill: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'heading_typography',
                'label' => __('Typography', 'shadepro-ts'),
                'scheme' => \Elementor\Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .shadepro-heading  ',
            ]
        );


        $this->add_control(
            'heading_color',
            [
                'label' => __('Heading Color', 'shadepro-ts'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#fff',
                'selectors' => [
                    '{{WRAPPER}} .shadepro-heading' => 'color: {{VALUE}}',
                ],
            ]
        );


        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'heading_border',
                'label' => __('Border', 'shadepro-ts'),
                'selector' => '{{WRAPPER}} .shadepro-heading',
            ]
        );
        $this->add_responsive_control(
            'heading_padding',
            [
                'label' => __('Heading Padding', 'shadepro-ts'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'default' => [
                    'top' => '0',
                    'right' => '0',
                    'bottom' => '0',
                    'left' => '0',
                ],
                'selectors' => [
                    '{{WRAPPER}} .shadepro-heading' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'heading_radius',
            [
                'label' => __('Border Radius', 'shadepro-ts'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'default' => [
                    'top' => '0',
                    'right' => '0',
                    'bottom' => '0',
                    'left' => '0',
                ],
                'selectors' => [
                    '{{WRAPPER}} .shadepro-heading' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],

            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'heading_shadow',
                'label' => __('Heading Shadow', 'shadepro-ts'),
                'selector' => '{{WRAPPER}} .shadepro-heading',
                'fields_options' =>
                [
                    'box_shadow_type' =>
                    [
                        'default' => 'yes',
                    ],
                    'box_shadow' => [
                        'default' =>
                        [
                            'horizontal' => 0,
                            'vertical' => 0,
                            'blur' => 0,
                            'spread' => 0,
                            'color' => 'rgba(128, 128, 128, 0.16)',
                        ],
                    ],
                ],
            ]
        );
        $this->add_control(
            'heading_hover_animation',
            [
                'label' => __('Hover Animation', 'shadepro-ts'),
                'type' => \Elementor\Controls_Manager::HOVER_ANIMATION,
                // 'prefix_class' => 'elementor-animation-',
            ]
        );
        $this->end_controls_section();
    }

    /**
     * Render oEmbed widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render()
    {
        $popular_post_key = array();
        $popular_meta_value_num = array();
        $settings = $this->get_settings_for_display();
?>
        <div class="shadepro-heading-wrapper ">
            <<?php echo $settings['heading_tags']; ?> class="shadepro-heading <?php echo esc_attr(' elementor-animation-' . $settings['heading_hover_animation']) ?>">
            
            <?php if (!empty($settings['heading_url']['url'])) : ?>
                <a href="<?php echo $settings['heading_url']['url'] ?>">
                <?php endif; ?>
                <?php if ('before' == $settings['icon_position'] && !empty($settings['icon']['value'])) : ?>
                    <span class="icon-before  heading-icon"><?php \Elementor\Icons_Manager::render_icon($settings['icon'], ['aria-hidden' => 'true']) ?></span>
                <?php endif; ?>
                
                <?php do_action( 'shadepro_before_page_title', '' ); ?>
                <?php echo $settings['custom_title'] == 'yes'? $settings['heading_label'] : apply_filters( 'shadepro_page_title', get_the_title(  ), null ); ?>
                <?php do_action( 'shadepro_after_page_title', '' ); ?>


                <?php if ('after' == $settings['icon_position'] && !empty($settings['icon']['value'])) : ?>
                    <span class="icon-after heading-icon"><?php \Elementor\Icons_Manager::render_icon($settings['icon'], ['aria-hidden' => 'true']) ?></span>
                <?php endif; ?>
                <?php if (!empty($settings['heading_url']['url'])) : ?>
                </a>
            <?php endif; ?>
            </<?php echo $settings['heading_tags']; ?>>
        </div>
<?php
    }
}
