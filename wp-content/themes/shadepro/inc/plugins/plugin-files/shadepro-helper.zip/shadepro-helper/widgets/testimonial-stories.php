<?php


/**
 * Elementor oEmbed Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class ShadeProTestimonialStories extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve oEmbed widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'shadepro-testimonial-stories';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve oEmbed widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'ShadePro Testimonial Stories', 'shadepro-ts' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve oEmbed widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-testimonial';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the oEmbed widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'shadepro-addons' ];
	}

	/**
	 * Register oEmbed widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls() {

		/**
		 * Content tab
		 */
		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content', 'shadepro-ts' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'testimonial_title',
			[
				'label' => __( 'Testimonial title', 'shadepro-ts' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => '',
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'quote_icon',
			[
				'label' => __( 'Select Quote Icon', 'shadepro-ts' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-quote-left',
					'library' => 'solid',
				],
			]
        );
		$repeater->add_control(
			'image',
			[
				'label' => __( 'Choose Image', 'shadepro-ts' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);


		$repeater->add_control(
			'content', [
				'label' => __( 'Content', 'shadepro-ts' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'show_label' => true,
			]
		);

		$repeater->add_control(
			'star',
			[
				'label' => __( 'Select star', 'shadepro-ts' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => '5',
				'options' => [
					'1' => __( '1', 'shadepro-ts' ),
					'2' => __( '2', 'shadepro-ts' ),
					'3' => __( '3', 'shadepro-ts' ),
					'4' => __( '4', 'shadepro-ts' ),
					'5' => __( '5', 'shadepro-ts' ),
				],
			]
		);

		$repeater->add_control(
			'company_icon',
			[
				'label' => __( 'Select Company Icon', 'shadepro-ts' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-star',
					'library' => 'solid',
				],
			]
        );
		$repeater->add_control(
			'name', [
				'label' => __( 'Name', 'shadepro-ts' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'David Mark' , 'shadepro-ts' ),
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'title', [
				'label' => __( 'Title', 'shadepro-ts' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'CEO of Lapsas' , 'shadepro-ts' ),
				'show_label' => true,
			]
		);
		$this->add_control(
			'testimonial',
			[
				'label' => __( 'Repeater List', 'shadepro-ts' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'slide_settings',
			[
				'label' => __( 'SLide Settings', 'shadepro-ts' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);


		$this->add_control(
			'prev_text',
			[
				'label' => __( 'Prev Text', 'shadepro-ts' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'fields' => $repeater->get_controls(),
				'default' => 'Prev Story',
			]
		);
		$this->add_control(
			'next_text',
			[
				'label' => __( 'Prev Text', 'shadepro-ts' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'fields' => $repeater->get_controls(),
				'default' =>  'Next Story',
			]
		);


		$this->end_controls_section();

		/**
		 * Style tab
		 */

		$this->start_controls_section(
			'general',
			[
				'label' => __( 'General', 'shadepro-ts' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'title_gap',
			[
				'label' => __( 'Title Gap', 'shadepro-ts' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => 45,
					'unit' => 'px',
				],
				'tablet_default' => [
					'size' => 30,
					'unit' => 'px',
				],
				'mobile_default' => [
					'size' => 20,
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}}  .shadepro-testimonial-story-content .testimonial-title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'star_gap',
			[
				'label' => __( 'Star Icon Gap', 'shadepro-ts' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => 30,
					'unit' => 'px',
				],
				'tablet_default' => [
					'size' => 25,
					'unit' => 'px',
				],
				'mobile_default' => [
					'size' => 20,
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}}  .shadepro-testimonial-story-content .testimonial-star' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'content_gap',
			[
				'label' => __( 'Content Gap', 'shadepro-ts' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => 30,
					'unit' => 'px',
				],
				'tablet_default' => [
					'size' => 25,
					'unit' => 'px',
				],
				'mobile_default' => [
					'size' => 20,
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}}  .shadepro-testimonial-story-content p' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);


		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'heading_typography',
				'label' => __( 'Title Typography', 'shadepro-ts' ),
				'scheme' => \Elementor\Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .shadepro-testimonial-story-content .testimonial-title',
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'content_typography',
				'label' => __( 'Content Typography', 'shadepro-ts' ),
				'scheme' => \Elementor\Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .shadepro-testimonial-story-content p',
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'cname_typography',
				'label' => __( 'CUstomer Name Typography', 'shadepro-ts' ),
				'scheme' => \Elementor\Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .shadepro-testimonial-story-content .customer-name',
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'ctitle_typography',
				'label' => __( 'Customer Title Typography', 'shadepro-ts' ),
				'scheme' => \Elementor\Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .shadepro-testimonial-story-content .customer-title',
			]
		);


		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'icon_shadow',
				'label' => __( 'Customer Icon Shadow', 'shadepro-ts' ),
				'selector' => '{{WRAPPER}} .shadepro-testimonial-story-content .shadepro-testimonial-company-icon',
				'fields_options' =>
				[
					'box_shadow_type' =>
					[
						'default' =>'yes'
					],
					'box_shadow' => [
						'default' =>
							[
								'horizontal' => -2,
								'vertical' => 16,
								'blur' => 27,
								'spread' => 0,
								'color' => 'rgba(111, 118, 138, 0.16)'
							]
					]
				]

			]
		);



		$this->end_controls_section();


	}

	/**
	 * Render oEmbed widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		?>
		<?php if ( $settings['testimonial'] ) :?>
		<div class="shadepro-testimonial-stories swiper-container">
			<div class="shadepro-testimonial-storis-wrapper swiper-wrapper">
				<?php foreach($settings['testimonial'] as  $testimonial):  ?>
					<div class="shadepro-testimonial-story swiper-slide">
						<div class="container">
							<div class="row">
								<div class="col-md-6">
									<div class="shadepro-testimonial-story-image">
										<span class="shadepro-testimonial-quote-icon"><?php \Elementor\Icons_Manager::render_icon( $testimonial["quote_icon"], [ 'aria-hidden' => 'true' ] ); ?></span>
										<img src="<?php echo $testimonial['image']['url'] ?>" alt="<?php echo esc_attr__( 'Client testimonial', 'shadepro-ts' ) ?>">
									</div>
								</div>
								<div class="col-md-6">
									<div class="shadepro-testimonial-story-content">
										<h3 class="testimonial-title"><?php echo $settings['testimonial_title'] ?></h3>
										<div class="testimonial-star">
											<?php for($i=0;$i<$testimonial['star'];$i++): ?>
												<i class="fa fa-star"></i>
											<?php endfor; ?>
										</div>
										<p><?php echo esc_html( $testimonial['content'] ) ?></p>
										<div class="customer-meta">
											<span class="shadepro-testimonial-company-icon"><?php \Elementor\Icons_Manager::render_icon( $testimonial["company_icon"], [ 'aria-hidden' => 'true' ] ); ?></span>
											<div class="customer-meta-content">
												<h4 class="customer-name"><?php echo $testimonial['name'] ?></h4>
												<span class="customer-title"><?php echo $testimonial['title'] ?></span>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				<?php endforeach;  ?>
			</div>
			<!-- Add Pagination -->
			<div class="container">
				<div class="row align-items-center">
					<div class="col-md-6 offset-md-6">
						<div class="swiper-navigation">
							<button class="swipe-prev" type="button"><?php echo $settings['prev_text'] ?></button>
							<button class="swipe-next" type="button"><?php echo $settings['next_text'] ?></button>
						</div>
					</div>
				</div>
			</div>
		</div>
		  <!-- Initialize Swiper -->
		  <script>
			  jQuery(document).ready(function(){
				var swiper = new Swiper('.shadepro-testimonial-stories', {
					slidesPerView: 1,
					navigation: {
						nextEl: '.swipe-next',
						prevEl: '.swipe-prev',
					},

				});

			  })
		</script>
		<?php endif; ?>
		<?php
	}

}

