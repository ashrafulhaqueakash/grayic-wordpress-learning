<?php


/**
 * Elementor oEmbed Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class ShadeProTestimonial extends \Elementor\Widget_Base
{

	/**
	 * Get widget name.
	 *
	 * Retrieve oEmbed widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name()
	{
		return 'shadepro-testimonial';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve oEmbed widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title()
	{
		return __('ShadePro Testimonial', 'shadepro-ts');
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve oEmbed widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon()
	{
		return 'eicon-icon-box';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the oEmbed widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories()
	{
		return ['shadepro-addons'];
	}

	/**
	 * Register oEmbed widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls()
	{

		/**
		 * Content tab
		 */
		$this->start_controls_section(
			'content_section',
			[
				'label' => __('Content', 'shadepro-ts'),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'image',
			[
				'label' => __('Choose Image', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);
		$this->add_control(
			'image_position',
			[
				'label' => __('Image Position', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'default' => 'top',
				'options' => [
					'left' => [
						'title' => __('Left', 'shadepro-ts'),
						'icon' => 'eicon-h-align-left',
					],
					'top' => [
						'title' => __('Top', 'shadepro-ts'),
						'icon' => 'eicon-v-align-top',
					],
					'right' => [
						'title' => __('Right', 'shadepro-ts'),
						'icon' => 'eicon-h-align-right',
					],
				],
				'prefix_class' => 'shade-position-',
				'toggle' => true,
			]
		);

		$this->add_control(
			'name',
			[
				'label' => __('Name', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'default' => __('Customer Name', 'shadepro-ts')
			]
		);

		$this->add_control(
			'title',
			[
				'label' => __('Title', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'default' => __('Easy Intragition', 'shadepro-ts')
			]
		);

		$this->add_control(
			'description',
			[
				'label' => __('Content', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => __('Lorem ipsum dolor sit amet, consetetur sadipscing elitr love it', 'shadepro-ts')
			]
		);



		$this->add_control(
			'content_align',
			[
				'label' => __('Align', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __('Left', 'shadepro-ts'),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __('top', 'shadepro-ts'),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __('Right', 'shadepro-ts'),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'center',
				'toggle' => true,
			]
		);

		$this->end_controls_section();
		/**
		 * Style tab
		 */

		$this->start_controls_section(
			'image_style',
			[
				'label' => __('Image', 'shadepro-ts'),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
			'image_sizes',
			[
				'label' => __('Image Size', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .shade-testimonial-item .testi-image img ' => 'width: {{SIZE}}{{UNIT}};height: {{SIZE}}{{UNIT}};',
				],
			]
		);
/* 		$this->add_responsive_control(
			'image_gap',
			[
				'label' => __('Image Gap', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .shade-position-top .shade-testimonial-item .testi-image' => 'margin-bottom: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .shade-position-left .shade-testimonial-item .testi-image' => 'margin-left: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .shade-position-right .shade-testimonial-item .testi-image' => 'margin-right: {{SIZE}}{{UNIT}};',
				],
			]
		); */

		$this->add_responsive_control(
			'image_margin',
			[
				'label' => __('Box Padding', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors' => [
					'{{WRAPPER}} .shade-testimonial-item .testi-image' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		$this->start_controls_section(
			'content_style',
			[
				'label' => __('Content', 'shadepro-ts'),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);


		$this->add_control(
			'desscription_color',
			[
				'label' => __('Description Color', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .shade-testimonial-item .testi-content p' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'description_typography',
				'label' => __('Description Typography', 'shadepro-ts'),
				'selector' => '{{WRAPPER}} .shade-testimonial-item .testi-content p ',
			]
		);

		$this->add_responsive_control(
			'desc_gap',
			[
				'label' => __('Title Gap', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .shade-testimonial-item .testi-content p ' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);



		$this->add_control(
			'desc_br',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);

		$this->add_control(
			'name_color',
			[
				'label' => __('Name Color', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .shade-testimonial-item .testi-meta .testi-name' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'name_typography',
				'label' => __('Name Typography', 'shadepro-ts'),
				'selector' => '{{WRAPPER}} .shade-testimonial-item .testi-meta .testi-name ',
			]
		);
		$this->add_control(
			'name_style_br',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);

		$this->add_control(
			'title_color',
			[
				'label' => __('Title Color', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .shade-testimonial-item .testi-meta .testi-title' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'label' => __('Title Typography', 'shadepro-ts'),
				'selector' => '{{WRAPPER}} .shade-testimonial-item .testi-meta .testi-title ',
			]
		);

		$this->end_controls_section();
		$this->start_controls_section(
			'box_style',
			[
				'label' => __('Box', 'shadepro-ts'),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'box_background',
			[
				'label' => __('Box Background Color', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .shade-testimonial-item ' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'box_border_radius',
			[
				'label' => __('Box Border Radius', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors' => [
					'{{WRAPPER}} .shade-testimonial-item  ' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'box_padding',
			[
				'label' => __('Box Padding', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors' => [
					'{{WRAPPER}} .shade-testimonial-item ' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'border',
				'label' => __('Border', 'shadepro-ts'),
				'selector' => '{{WRAPPER}} .shade-testimonial-item ',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'box_shadow',
				'label' => __('Box Shadow', 'shadepro-ts'),
				'selector' => '{{WRAPPER}} .shade-testimonial-item ',
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'box_hover_shadow',
				'label' => __('Box Hover Shadow', 'shadepro-ts'),
				'selector' => '{{WRAPPER}} .shade-testimonial-item :HOVER',
			]
		);

		$this->add_responsive_control(
			'box_optacity',
			[
				'label' => __('Box Opacity', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1,
						'step' => .01,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .shade-testimonial-item ' => 'opacity: {{SIZE}}',
				],
			]
		);
		$this->add_responsive_control(
			'box_min_height',
			[
				'label' => __('Min Height', 'shadepro-ts'),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .shade-testimonial-item ' => 'min-height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render oEmbed widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render()
	{
		$settings = $this->get_settings_for_display();


?>
		<div class="shade-testimonial-item <?php echo esc_attr($settings['image_position']) ?>">

			<?php if (!empty($settings['image']['url'])) : ?>
				<div class="testi-image">
					<?php echo \Elementor\Group_Control_Image_Size::get_attachment_image_html($settings);
					?>
				</div>
			<?php endif; ?>
			<div class="test-content-wrap">
				<div class="testi-content">
					<p><?php echo $settings['description'] ?></p>
				</div>
				<div class="testi-meta">
					<h4 class="testi-name"><?php echo $settings['name'] ?></h4>
					<span class="testi-title"><?php echo $settings['title'] ?></span>
				</div>
			</div>
		</div>
<?php
	}
}
